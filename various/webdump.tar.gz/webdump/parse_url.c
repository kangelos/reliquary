/*
* parse_url
*	it only include the parseURL function that accepts
*	a URL in char * format , gropes it and returns a url_t
*	data structure instance
*/
static char *version =" @(#)parse_url.c	1.14 URL checker 95/01/19 ";

#include "www.h"
#include "url.h"


/* ---------------
	parseURL accepts a Url as input , scans it for correctnes
	identifies all the elements in it , ie hostname/path/port etc
	and returns either a valid url_t or NULL if there was some mistake
	no check is donw when mallocing swappingshould be enabled 
 ---------------*/
url_t *parseURL(char *url)
{
char portnum[10],temp[100],*where,protocol[100];
char tname[100],fname[100],resource[100];
int  i,protocolnum;
url_t *myurl;


strcpy(temp,url); /* local copy */
where=temp; 	  /* and use this to go about */

i=0;
while ( (((char)*where) != ':' ) && (((char)*where) != (char )NULL ) ) /* protocol entry */
	protocol[i++]=*where++;

protocol[i]='\0';

protocolnum=P_UNKNOWN;  /* default value */

if ( strcasecmp(protocol,"http") == 0)
	protocolnum=P_HTTP;
if ( strcasecmp(protocol,"file") == 0)
	protocolnum=P_FILE;
if ( strcasecmp(protocol,"ftp") == 0)
	protocolnum=P_FTP;
if ( strcasecmp(protocol,"telnet") == 0)
	protocolnum=P_TELNET;
if ( strcasecmp(protocol,"gopher") == 0)
	protocolnum=P_GOPHER;

if ((protocolnum==P_UNKNOWN) &&
    ( temp[0]=='/')){                /* maybe it is a file, assume it is */
		protocolnum=P_FILE;
		where=temp;	/* reset scanner for later use */
}

if ( (char)*where==':')
	*where++; /* skip the ":" */

if (protocolnum == P_FILE ){	/* special case of file */
	if ( strncmp(where,"/",1) != 0){
		printf("Malformed URL\n");
		return NULL;
	}	
	else
		strcpy(fname,where);	/* not necessary */

			/* set up the URL */
		myurl=(url_t *) malloc(sizeof(url_t));
		myurl->protocolType=protocolnum;
		myurl->info.file.pathname=(char *)
				malloc(sizeof(char)*(strlen(fname)+1));
		strcpy(myurl->info.file.pathname,fname);
		return myurl;
}

		/* some other protocol than FILE */

if ( strncmp(where,"//",2) != 0){
	printf("Malformed URL\n");
	return NULL;
}	
*where++;
*where++; /* go past the // */

i=0;
while ((*where != ':' ) && (*where != '/' ) && (*where != (char)NULL))
	tname[i++]=*where++;

tname[i]='\0'; /* got the hostname */

if ( *where == '/' ){
	i=0; /* file requested */
	while ( (*where != ':' ) && (*where != (char)NULL ) ) 
		resource[i++]=*where++;
	resource[i]='\0';
}
else
	strcpy(resource,DEF_RESOURCE);  

if (*where == ':'){    /* get the port number */
	*where++; /* skip it */
	i=0;
	while ( (*where != '/') && (*where != (char)NULL))  /* get the port Number */
		portnum[i++]=*where++;
	portnum[i]='\0';
}
else{
	if (protocolnum == P_HTTP )
		strcpy(portnum,HTTP_PORT);
	if (protocolnum == P_GOPHER )
		 strcpy(portnum,GOPHER_PORT);

}

/* just in case filename was specified after port number */

if ( *where == '/' ) { /* file name follows */
	if (strlen(resource)==0)	
		strcpy(resource,where);
}

	/* we are ready to built the URL */
myurl=(url_t *) malloc(sizeof(url_t)); 
myurl->protocolType=protocolnum;

if (protocolnum==P_HTTP){
myurl->info.http.portNumber=atoi(portnum);

myurl->info.http.hostName=(char *) malloc(sizeof(char)*(strlen(tname)+1));
strcpy(myurl->info.http.hostName,tname);

myurl->info.http.identifier=(char *) malloc(sizeof(char)*(strlen(resource)+1));
strcpy(myurl->info.http.identifier,resource);
}

if (protocolnum==P_GOPHER){
myurl->info.gopher.portNumber=atoi(portnum);

myurl->info.gopher.hostName=(char *) malloc(sizeof(char)*(strlen(tname)+1));
strcpy(myurl->info.gopher.hostName,tname);

myurl->info.gopher.identifier=(char *) malloc(sizeof(char)*(strlen(resource)+1));
strcpy(myurl->info.gopher.identifier,resource);
}


return myurl;
}
