/*
	io.c
	this file concentrates the socket io read and write functions
Functions:
	writen    writes characters to socket
	readline  reads lines from socket
*/

static char *version ="@(#)io.c	1.1 1.0 Socket IO Functions";



#include "www.h"

extern char resource[400]; /* kludgy */

/* ---------------------------------------------------------------------
read a line from a socket descriptor (fd) into (ptr) 
   of maximum length (maxlen)
   returns -1 if not good or the number of characters read
 zaps the \n character
  copied from stevens' book
-------------------------------------------*/
int readline(fd,ptr,maxlen)
int fd,maxlen;
char *ptr;
{
int n,rc;
char c;
	for (n=1; n<maxlen; n++){
		if ( (rc=read(fd,&c,1)) ==1) {
			*ptr++=c;
			*ptr='\0'; /* just checking */
			if (c=='\n')
				break;
		}
		else if (rc == 0){
			if ( n ==1 )
				return(0);
			else
				break;
		} else
			return(-1);
}
*ptr='\0';
return(n);
}	

/*-------------------------------------------------- 
	Function writen
	attempts to write to FD the string pointed to by PTR for nbytes number
	of characters
	returns the number of the ones remaining to be written
	copied form steves' book
-------------------------------------------------- */

int writen(fd,ptr,nbytes)
int fd,nbytes;
char *ptr;
{
int nleft,nwritten;
char *loc=ptr;

nleft=nbytes;

	while (nleft>0){
		nwritten=write(fd,loc,nleft);
		if (nwritten <= 0)
			return(nwritten);
		nleft -= nwritten;
		loc += nwritten;
	}
return(nbytes-nleft);
}

