/*
* parse get function
*  takes as a parameter the incoming line from the client
*	sets the type accordingly
*	and returns a pointer to the rest of the string
*
*/


static char *version="@(#)parseget.c	1.2 get line parser 94/11/27";


#include "www.h"



/*
* parse get function
*  takes as a parameter the incoming line from the client
*	sets the type according to the First token of the line
*	and returns a pointer to the rest of the string
*
*/
char *parseGET(int *type,char *line)
{
char temp[200],*token;

strcpy(temp,line);

*type=M_ENDOFHEADER; /* What Done Already ? */
token=strtok(temp,": ");

if (strcasecmp(token,"Accept")==0)
	*type=R_ACCEPT;

if (strcasecmp(token,"From")==0)
	*type=R_FROM;

if (strcasecmp(token,"User-Agent")==0)
	*type=R_USER_AGENT;

if (strcasecmp(token,"GET")==0)
	*type=M_GET;

token=strtok(NULL,"\r\n");
return token;
}
