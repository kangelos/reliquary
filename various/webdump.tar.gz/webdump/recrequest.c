static char *version="@(#)recrequest.c	1.5 request receiver %d%";
/*
	receives requests from a sockfd until no more are read 
	returns a pointer to the head of a link list of requests
*/


#include "www.h"
#include "http.h"


/* ------
	receiveRequest
	Parameter an open sockfd
	returns a link list of requests made to the server or NULL
	if none were read.
	I should have broken it to the link list functions and
	the control separately, but I got lazy
----*/
line_info_t *receiveRequest(int newsockfd){
char incoming[400],temp[400];
char *pointer,*infoget;
line_info_t *start,*current,*save,*new;
int readchars,first,type;


start=NULL;
first=1;
/* receive the client requests */
memset(incoming,' ',sizeof(incoming));
while (strlen(incoming)>2)    {    /* no empty line yet \n + \r=2 bytes */
		/* get one input line */
	readchars=readline(newsockfd,incoming,sizeof(incoming)-1);
	/* incoming[strlen(incoming)-2]='\0';		  zap \r\n */
	if ( strlen(incoming)>2){
				/* insert into list */
		if (first){		/* find where it goes first */
			first=0;
			start=(line_info_t *)malloc(sizeof(line_info_t));
			start->next=NULL;
			infoget=parseGET(&type,incoming);
			if (infoget != NULL)
				start->info=strdup(infoget);
			start->typeCode=type;
		}
		else {
					/* insert here */	
			current=start;
			while (current!=NULL){ /* find location */
				save=current;
				current=current->next;
			}
			new=(line_info_t *)malloc(sizeof(line_info_t));
			new->next=NULL;
			infoget=parseGET(&type,incoming);
			if (infoget != NULL)
				new->info=strdup(infoget);
			new->typeCode=type;
			save->next=new;
		}
	}
}
return start;
}

