#!/usr/bin/perl
#
# DNS statistics package for the Greek Domain
# Copyright and copy Angelos Karageorgiou
# Nov 2000
#


use Socket;

%HOSTS={};
$olddomain="";
$domain="";
$server="";
$oldserver="";
while(<>){
	chomp;
	($server,$domain)=split(" ",$_);

	if ($oldserver =~ /^$server$/){
		print "." x length($server);
		print "	$domain\n";
		$count++;
	} else {
		print "\n";

		print " " x 40;
		$name=resolv($server);
		print "\n$oldserver  $name     Total:$count\n\n" ;
		print "-" x 79 ;
		print "\n\n\n";
		print "$server	$domain\n";	
		$count=1;
	}
	$oldserver=$server;
}



sub resolv #resolv and cache a host name
{
local $mname,$miaddr,$mhost;
$mhost=shift;
$timeout=5;

        $miaddr = inet_aton($mhost); # or whatever address
        if (! $HOSTS{$mhost} ) {
                $mname='';


    eval {
        local $SIG{ALRM} = sub { die "alarm\n" };       # NB \n required
        alarm $timeout;

        $mname  = gethostbyaddr($miaddr, AF_INET);

        alarm 0;
    };
    die if $@ && $@ ne "alarm\n";       # propagate errors

                if  ( $mname =~ /^$/ )  {
                        $mname=$mhost;
                }
                $HOSTS{$mhost}=$mname;
        }
return $HOSTS{$mhost}
}

