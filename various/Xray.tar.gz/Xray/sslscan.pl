#!/usr/bin/perl --

use LWP::UserAgent;
use HTTP::Request;
use Socket;

@HOSTS={};

if($ARGV[0] eq undef)
{
   print "USAGE: sslscan.pl server_list_file outfile\n";
   print "EXAMPLE: sslscan.pl Mon-30-10-2000/domains_alive outfile\n";
   exit;
}


if($ARGV[1] eq undef) {
	$skip=0;
} else {
	$skip=$ARGV[1];
}
$SIG{PIPE} = 'IGNORE';
$dummy="";
$filename=$ARGV[0];
$outfile=$ARGV[1];
$serveraddr="";

@WEBS=();

&read_www;

$item=0;
$ua = new LWP::UserAgent;
$ua->agent('xirbot/1.69');
$ua->timeout(15);
open(OUT,">$outfile") || die "Cannot create output\n";
select OUT;
$|=1;
$timeout=15;
foreach $server (@WEBS) {

	$URL="https://" . $server . ":443";

print STDOUT "$URL\n";

	$item="";
	@headers=();
	$ip="";
	$softw="Server Irresponsive";
	$Auth="NOSSL";
	$cipher="NOCipher";
	$name=$server;
    eval {
        local $SIG{ALRM} = sub { die "alarm\n" };       # NB \n required
        alarm $timeout;

	$request = new HTTP::Request('HEAD', $URL);
	$response = $ua->request($request);
	if ($response->is_success)  {
		$name=resolv($server);
   		@headers=split('\n',$response->headers_as_string);
		foreach $item (@headers){
			if ($item =~ /Server\:/i) {
				($dummy,$softw)=split(':',$item);
				}
			if ($item =~ /Client-peer\:/i) {
				($dummy,$ip)=split(":",$item);
				}
			if ($item =~ /Client-SSL-Cert-Issuer\:/i) {
				($dummy,$Auth)=split(":",$item);
				}
			if ($item =~ /Client-SSL-Cipher\:/i) {
				($dummy,$cipher)=split(":",$item);
				}
		}
		
 	}
    };
    die if $@ && $@ ne "alarm\n";       # propagate errors
	
	print OUT "$server:$softw:$name:$Auth:$cipher\n";

}

close(OUT);
1;

sub read_www{
open(WWWLIST,"<$filename") or die "no WWW list $filename\n";	
	while(<WWWLIST>){
		chomp($_);
		$domain=$_;
		if ( $domain =~ /\(/ ) {
			$domain =~ s/\(//;
			$domain =~ s/\).*$//;
		}
		push(@WEBS,$domain);
	}
close(WWWLIST);
}


sub resolv #resolv and cache a host name
{
local $mname,$miaddr,$mhost;
$mhost=shift;

        $miaddr = inet_aton($mhost); # or whatever address
  if (! $HOSTS{$mhost} ) {
        $mname='';
        $mname  = gethostbyaddr($miaddr, AF_INET);

        if  ( $mname =~ /^$/ )  {
                        $mname=$mhost;
        }
        $HOSTS{$mhost}=$mname;
   }
return $HOSTS{$mhost};
}

