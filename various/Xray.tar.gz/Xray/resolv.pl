#!/usr/bin/perl

@HOSTS={};

use Socket;

if($ARGV[0] eq undef)
{
   print "USAGE: revdns.pl server_list_file\n";
   print "EXAMPLE: myscan.pl Mon-30-10-2000/webserver_ips\n";
   exit;
}

$dummy="";
$filename=$ARGV[0];
$outfile=$ARGV[1];
$serveraddr="";

@WEBS=();

&read_www;


open(OUT,">$outfile") || die "cannot create $outfile\n";
select OUT;
$|=1;

$i=0;
foreach $ip (@WEBS){
	$name=resolv($ip);
	print OUT "$COUNTS[$i]	$ip	$name\n";
	$i++;
}
close(out);
1;

sub resolv #resolv and cache a host name
{
local $mname,$miaddr,$mhost;
$mhost=shift;
$timeout=5;

        $miaddr = inet_aton($mhost); # or whatever address
        if (! $HOSTS{$mhost} ) {
                $mname='';


    eval {
        local $SIG{ALRM} = sub { die "alarm\n" };       # NB \n required
        alarm $timeout;

        $mname  = gethostbyaddr($miaddr, AF_INET);

        alarm 0;
    };
    die if $@ && $@ ne "alarm\n";       # propagate errors

                if  ( $mname =~ /^$/ )  {
                        $mname=$mhost;
                }
                $HOSTS{$mhost}=$mname;
        }
return $HOSTS{$mhost}
}


sub read_www{
open(WWWLIST,"<$filename") or die "no WWW list\n";
        while(<WWWLIST>){
                chomp($_);
		
                ($count,$domain)=split("	",$_);
		$domain =~ s/ //;
                if ( $domain =~ /\(/ ) {
                        $domain =~ s/\(//;
                        $domain =~ s/\).*$//;
                }
                push(@WEBS,$domain);
                push(@COUNTS,$count);
        }
close(WWWLIST);
}


sub foralarm{
	return 1;
}

