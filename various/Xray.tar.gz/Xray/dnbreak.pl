#!/usr/bin/perl --


if($ARGV[0] eq undef)
{
   print "USAGE: dnbreak.pl server_list_file\n";
   exit;
}


$dummy="";
$filefull=$ARGV[0];
$filealive=$ARGV[1];

@WEBS=();
%COMPS={};

&read_www;
&read_full;

foreach $server (@WEBS) {
#	if ( $server =~ /^ / ) { next; }
#	if ( $server =~ /^[0-9]+/ ) { $xserver="$server\n"; next; }
#	@parts=();
#	@xparts=();
#	@parts=split('\.',$server);
#	@xparts=reverse(@parts);
#	if ( $#parts >= 2 ) {
#		pop(@xparts);
#	}
#	@parts=reverse(@xparts);
#	foreach $el (@parts) {	
#		print "$el.";
#	}
	$xserver=$server;
	$xserver =~ s/www\.//g ;
	print "$COMPS{$xserver}	$server";
	print "\n";
}
1;

sub read_full{
open(WWWLIST,"<$filefull") or die "no WWW list\n";	
	while(<WWWLIST>){
		chomp($_);
		($domain,$server)=split('\t',$_);
		if ( $domain =~ /\(/ ) {
			$domain =~ s/\(//;
			$domain =~ s/\).*$//;
		}
		$COMPS{$domain}=$server;
	}
close(WWWLIST);
}

sub read_www{
open(WWWLIST,"<$filealive") or die "no WWW list\n";	
	while(<WWWLIST>){
		chomp($_);
		$domain=$_;
		if ( $domain =~ /\(/ ) {
			$domain =~ s/\(//;
			$domain =~ s/\).*$//;
		}
		push(@WEBS,$domain);
	}
close(WWWLIST);
}
