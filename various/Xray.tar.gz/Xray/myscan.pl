#!/usr/bin/perl --

use LWP::Simple;
use IPC::SysV;
use Socket;
use IPC::SysV qw(IPC_PRIVATE S_IRWXU IPC_CREAT);
use IPC::Semaphore;



%IPS={};
@PIDS=();
%SOFTW={};
$HOSTC=0;
$PROCESSES=24;

##############################################################################
##############################################################################
##########        Please modify the file                          ############
##########      /usr/lib/perl5/site_perl/5.005/LWP/Simple.pm      ############
##########      for a decent timeout                              ############
##############################################################################
##############################################################################


$timeout=5;  # useless here


if ( ($ARGV[0] eq undef) || ($ARGV[0] eq undef)) {
   print "USAGE: myscan.pl <server_list_file> <output file>\n";
   print "EXAMPLE: myscan.pl Mon-30-10-2000/domains_www Mon-30-10-2000/domains_scanned\n";
   exit;
}

$dummy="";
$filename=$ARGV[0];
$outfile=$ARGV[1];

###################
@WEBS=();
&read_www;
###################




use POSIX ":sys_wait_h";


$SIG{CHLD} = \&REAPER;




open(OUT,">>$outfile") || die "Cannot create output\n";

$hostwindow=int($HOSTC/$PROCESSES);

print "Trying to access $HOSTC hosts with $PROCESSES processes\n";
for ( $i=0 ; $i<$PROCESSES; $i++){

	my $pid = fork;

	( defined ($pid) ) or die "Cannot fork $@";

	if ( $pid==0 ) {	
		$PIDS[$i]=$pid;
	} else {
		# i am the child now
		$winstart=$i*$hostwindow;
		$winend=$i*$hostwindow+$hostwindow-1;
		print "Spawned process #$i $pid Processing $winstart $winend\n";
		dores($winstart,$winend) if ( $pid );
		exit;
	}
}


print "# back to the parent\n";

# back to the parent

$last=($PROCESSES-1)*$hostwindow+$hostwindow;
if ($last < $HOSTC ) {
	$winstart=$last;
	$winend=$HOSTC-1;
	print "Parent Processing $winstart $winend\n";
	dores($winstart,$winend);
}


for ( $i=0 ; $i<$PROCESSES; $i++){
	waitpid($PIDS[$i],0);
	print "Waiting on process #$i\n";
}
# web be waiting for the children here;
close(OUT);
1;

######################################################################
sub REAPER {
    my $child;
    while ($child = waitpid(-1,WNOHANG)) {
        $Kid_Status{$child} = $?;
    }
    $SIG{CHLD} = \&REAPER;  # still loathe sysV
}




######################################################################
sub dores{
$start=shift;
$end=shift;

    for ($j=$start;$j<=$end;$j++){

	$SERVER=$WEBS[$j];
	$ip=resolv($SERVER);
	if ( ! defined($ip) ) {
  		flock OUT,LOCK_SH;
                print  OUT  "$SERVER:Server Irresponsive:Unresolved\n";
                flock OUT,LOCK_UN;
		next;
        }
   


	if ( $IPS{$ip} ) {  # we have seen this again 
		$IPS{$ip}++;	
		flock OUT,LOCK_SH;
		print OUT "$SERVER:$SOFTW{$ip}:$ip:Cache Hit #$IPS{$ip}\n";
		flock OUT,LOCK_UN;
		next;
	}
	
	$IPS{$ip}=1;

	$server='';
	$url="http://www." . $SERVER . ":80/";
	($content_type, $document_length, $modified_time, $expires, $server)=get($url);


    	if ( $server =~ /^$/ ){
		flock OUT,LOCK_SH;
		print  OUT  "$SERVER:Server Irresponsive:Unresolved\n";
#	don't do this here
#		$SOFTW{$ip}="Server Irresponsive:Unresolved";
		flock OUT,LOCK_UN;
    	}
    	else {
		flock OUT,LOCK_SH;
		print OUT "$SERVER:$server:$ip\n";
		$SOFTW{$ip}=$server;
		flock OUT,LOCK_UN;
    	}
 	
   }
1;

}




#
#
#
sub read_www{
open(WWWLIST,"<$filename") or die "no WWW list $filename\n";	
	while(<WWWLIST>){
		chomp($_);
		$domain=$_;
		if ( $domain !~ /^$/) {
			if ( $domain =~ /\(/ ) {
				$domain =~ s/\(//;
				$domain =~ s/\).*$//;
			}
			push(@WEBS,$domain);
			$HOSTC++;
		}
	}
close(WWWLIST);
}








#DNS resolver

sub resolv {
local $mname,$miaddr,$mhost,$ip;
$mhost=shift;


     local(@mname)  = gethostbyname($mhost);
                return undef unless @mname;
     $serveraddr = $mname[4];

     $ip=inet_ntoa($serveraddr);


return $ip;
}


