#!/usr/bin/perl --

if($ARGV[1] eq undef)
{
   print "USAGE: break.pl <file> <destination dir> [number of parts]\n";
   exit;
}


$dummy="";
$filename=$ARGV[0];
$mydir=$ARGV[1];


@WEBS=();

if($ARGV[2] eq undef){
	$PARTS=10;
} else {
	$PARTS=$ARGV[2];
}
$wwws=0;

&read_www;

$count=$wwws/$PARTS;



$item=0;
$mycount=0;
$filecount=0;
$filedigit=sprintf("%02d",$filecount);
$myfile=$mydir . "/" . "file" . "$filedigit";
open(OUT,">$myfile");
foreach $server (@WEBS) {

	print OUT "$server\n";
	$mycount++;
	if ( $mycount >= $count) {	
		$filecount++;
		close(OUT);
		$mycount=0;
		$filedigit=sprintf("%02d",$filecount);
		$myfile=$mydir . "/" . "file" . "$filedigit";
		open(OUT,">$myfile");
	}

}
close(OUT);
print $filecount . "\n";


sub read_www{
open(WWWLIST,"< $filename") or die "no WWW list $filename\n";	
	while(<WWWLIST>){
		chomp($_);
		$domain=$_;
		$wwws++;
		if ( $domain =~ /\(/ ) {
			$domain =~ s/\(//;
			$domain =~ s/\).*$//;
		}
		push(@WEBS,$domain);
	}
close(WWWLIST);
}
