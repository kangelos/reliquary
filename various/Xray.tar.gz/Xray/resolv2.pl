#!/usr/bin/perl

@HOSTS={};

use Socket;


$dummy="";
$filename=$ARGV[0];
$serveraddr="";

@WEBS=();

&read_www;



$i=0;
foreach $ip (@WEBS){
	$name=resolv($ip);
	print "$ip	$name\n";
	$i++;
}
close(out);
1;

sub resolv #resolv and cache a host name
{
local $mname,$miaddr,$mhost;
$mhost=shift;
$timeout=5;

        $miaddr = inet_aton($mhost); # or whatever address
        if (! $HOSTS{$mhost} ) {
                $mname='';


    eval {
        local $SIG{ALRM} = sub { die "alarm\n" };       # NB \n required
        alarm $timeout;

        $mname  = gethostbyaddr($miaddr, AF_INET);

        alarm 0;
    };
    die if $@ && $@ ne "alarm\n";       # propagate errors

                if  ( $mname =~ /^$/ )  {
                        $mname=$mhost;
                }
                $HOSTS{$mhost}=$mname;
        }
return $HOSTS{$mhost}
}


sub read_www{
open(WWWLIST,"<$filename") or die "no WWW list\n";
        while(<WWWLIST>){
                chomp($_);
		
               	$domain=$_;
		$domain =~ s/ //;
                if ( $domain =~ /\(/ ) {
                        $domain =~ s/\(//;
                        $domain =~ s/\).*$//;
                }
                push(@WEBS,$domain);
        }
close(WWWLIST);
}


sub foralarm{
	return 1;
}

