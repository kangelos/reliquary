#!/usr/bin/perl
#
# DNS statistics package for the Greek Domain
# Copyright and copy Angelos Karageorgiou
# Nov 2000
#


@DOMAINS=();
$olddomain="";
$domain="";
$server="";
$oldserver="";
while(<>){
	chomp;
	($domain,$server)=split("\t",$_);
	if (defined( $DOMAINS{$domain})){
		next;
	}

	$DOMAINS{$domain}=$server;

	@parts=();
        @xparts=();
        @parts=split('\.',$server);
        @xparts=reverse(@parts);
        if ( $#parts >= 2 ) {
                pop(@xparts);
        }
        @parts=reverse(@xparts);

	print "$domain	";	
        foreach $el (@parts) {
                print "$el.";
        }
	print "\n";
}

