#!/usr/bin/perl --


if($ARGV[0] eq undef)
{
   print "USAGE: myscan.pl server_list_file\n";
   print "EXAMPLE: myscan.pl Mon-30-10-2000/domains_www\n";
   exit;
}


if($ARGV[1] eq undef) {
	$skip=0;
} else {
	$skip=$ARGV[1];
}

$dummy="";
$filename=$ARGV[0];
$outfile=$ARGV[1];
$serveraddr="";

@WEBS=();

&read_www;

$item=0;
open(OUT,">$outfile") || die "Cannot create output\n";
select OUT;
$|=1;
foreach $server (@WEBS) {


	$URL="http://" . $server;

	$command="/usr/Xray/webcrawler $URL";
	$result=`$command`;

		print OUT "$result";
   	
}
close(OUT);
1;

sub read_www{
open(WWWLIST,"<$filename") or die "no WWW list $filename\n";	
	while(<WWWLIST>){
		chomp($_);
		$domain=$_;
		if ( $domain =~ /\(/ ) {
			$domain =~ s/\(//;
			$domain =~ s/\).*$//;
		}
		push(@WEBS,$domain);
	}
close(WWWLIST);
}


#DNS resolver

sub resolv {
local $mname,$miaddr,$mhost;
$mhost=shift;

     local(@mname)  = gethostbyname($mhost);
                return undef unless @mname;
     $serveraddr = $mname[4];

return $serveraddr;
}

