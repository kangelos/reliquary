#!/usr/bin/perl
#
# DNS statistics package for the Greek Domain
# Copyright and copy Angelos Karageorgiou
# Nov 2000
#


$olddomain="";
$domain="";
$server="";
$oldserver="";
$total=0;
$xtotal=0;
while(<>){
	chomp;
	$total++;
	($server,$domain)=split("\t",$_);

	if ($oldserver =~ /^$server$/){
		print "." x length($server);
		print "	$domain\n";
		$count++;
	} else {
		print "\n";

		print " " x 40;
		print "\n$oldserver       Total:$count\n\n" ;
		print "-" x 79 ;
		print "\n\n\n";
		print "$server	$domain\n";	
		$xtotal += $count;
		$count=1;
	}
	$oldserver=$server;
}
                print "\n";

                print " " x 40;
                print "\n$oldserver       Total:$count\n\n" ;
                $xtotal += $count;
                $count=1;


