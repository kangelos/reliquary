#!/usr/bin/perl
#
# DNS statistics package for the Greek Domain
# Copyright and copy Angelos Karageorgiou
# Nov 2000
#
$DOM="gr"

@DOMAINS=();
$olddomain="";
$domain="";
$server="";
$oldserver="";
while(<>){
	chomp;
	$server=$_;

	if ( $server !~ /\.$/ ) {
		$server .= '.${DOM}';
	}


	@parts=();
        @xparts=();
        @parts=split('\.',$server);
        @xparts=reverse(@parts);
        if ( $#parts >= 2 ) {
                pop(@xparts);
        }
        @parts=reverse(@xparts);

        foreach $el (@parts) {
                print "$el.";
        }
	print "\n";
}

