/*                         
	Systen wide defines 
	(c) Angelos Karageorgiou

*/
#define BUF_SIZE 10000
#define FOREVER ( 1 == 1 )
#define DELIMITERS ",:"

/* function return results */
#define SUCCESS		1	
#define FAILURE		0
#define TRUE		1
#define FALSE		0
