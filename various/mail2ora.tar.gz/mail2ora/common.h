/*                         
	Primary Include file
	(c) Angelos Karageorgiou
*/

#include "defines.h"

/* stuff in mailfilter.c */
void init_ora(void);

/* stuff in oci8.c */
void send_msg(char *message);
void oci_cleanup();
