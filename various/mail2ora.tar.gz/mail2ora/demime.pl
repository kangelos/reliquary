#!/usr/bin/perl



$filename="/tmp/mpa.$$";

open(OUT,"> $filename") || die "Cannot create temp file";
print "$filename\n";
foreach (<STDIN>) {
	printf(OUT "%s", $_);
}
close(OUT);


#
#     Find the first text/plain part of the mail message and send it through
#
$command="/usr/bin/mhn -list -file $filename -nopause | grep text/plain | awk '{print \$1}'";

$part=`$command`;
chop($part);


if ( $part == 0 ) {
	$command="/bin.cat $filename | /etc/gsm/mail2ora";
}
else {
	$command="/usr/bin/mhn -show -nopause -part $part -file $filename -nopause | /etc/gsm/mail2ora";
}

system($command);

#unlink($filename);

