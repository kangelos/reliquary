/*

mail2ora   Angelos Karageorgiou


reads a mail message from stdin , sends it to oracle server


*/
#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <regex.h>
#include <syslog.h>
#include "common.h"


#define DEBUG 1


int main(int argc, char **argv){

char buffer[BUF_SIZE],message[100*BUF_SIZE];
char *cp,*sp1,*sp2;	/* a generic pointer to char */
long currlength;
int inheader,doneheader,from_mpa;

openlog(argv[0],LOG_PID,LOG_MAIL);


init_ora();
/****************************************************************************** 
                      MAIN LOOP  rather simple really
*******************************************************************************/

message[0]='\0'; /* stoopid init */
currlength=0;
inheader=0;
doneheader=0;
from_mpa=0;
while ( ! feof(stdin) )  {
	
	cp=fgets(buffer,sizeof(buffer)-1,stdin);


	if ( cp == NULL )
		break;

	if ( ( ! doneheader)  && ( !inheader ) ) {
		if ( strncasecmp(buffer,"From",4) == 0 ) {
			inheader=1;
		}

	}

	if ( ( ! doneheader)  && inheader ) {
		if ( strlen(buffer) == 1 ) {
			inheader=0;
			doneheader=1;
			continue;
		}
	}
		
	 

	if ( inheader ) {
		if ( strstr(buffer,"mpamail@philippos.mpa.gr") != NULL ) {
			from_mpa=1;
		}

		continue;
	}	


	sp1=strstr(buffer,"ATHENS STOCK EXCHANGE MARKET");
	sp2=strstr(buffer,"�������� ������ ����� �������������� ������");
	if ( (sp1 !=NULL) || (sp2!=NULL) ) {
		syslog(LOG_INFO,"This are the closings, I do not pass them:%s %s",message,buffer);
		exit(0);
	}
	currlength += strlen(buffer);
	if ( currlength > (sizeof(message) -1) ) {
		syslog(LOG_INFO,
			"Message too big, kept the first %d characters",
			currlength
			);
		break;
	}

	strcat(message,buffer);
}

if ( from_mpa ) {
#ifdef DEBUG
	syslog(LOG_INFO,"New Message buffer:%s",message);
#endif
	send_msg(message);	/* send the message to Oracle */
} else {
#ifdef DEBUG
	syslog(LOG_INFO,"Bad Message origin:%s",message);
#endif
}

closelog();
return(0);  /* Shell related success/failure is logic reversed on UNIX ! */
}


 
