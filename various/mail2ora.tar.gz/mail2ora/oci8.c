/*
#include <windows.h>
#include <winbase.h>
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <oci.h>
#include <time.h>
#include <syslog.h>
#include "common.h"

char username[]= {"user"};
char password[]= {"pass"};
char alias[]= {"db"};


/*****************************/
char fmsg[]= "BEGIN fnews(:message); END;";
/*****************************/



OCIEnv		*envhp;
OCIServer	*srvhp;
OCIError	*errhp;
OCISvcCtx	*svchp;
OCIStmt		*stmthp;
OCIDefine	*defnp = (OCIDefine *) 0;

OCIBind *bndp = (OCIBind *) 0; 

//variables for Oracle Call Interface	
char ocibuffer[100*BUF_SIZE];			//the ocibuffer
sb4	buf_length = sizeof(ocibuffer);	//ocibuffer size

static int  connect_to_ora();
static int  checkerr(OCIError *errhp, int status );


void init_ora(void)
{


// connect to oracle and prepare the PL/SQL statement
if (connect_to_ora()) {
	syslog(LOG_INFO,"Connected to server %s as %s",alias,username);
} else  {
	syslog(LOG_CRIT,"Unable to connect to Oracle %s",alias);
}




#ifdef DEBUG
	syslog(LOG_INFO,"binding ocibuffer");
#endif
checkerr( errhp, 
	OCIBindByName(
		stmthp, &bndp, errhp, ":message", strlen(":message"), 
		(dvoid *) ocibuffer, buf_length, SQLT_STR, (dvoid *) 0,
		(ub2 *) 0, (ub2 *) 0, (ub4) 0, (ub4 *) 0, OCI_DEFAULT
	)
);

}



int connect_to_ora()
{

OCISession *authp = (OCISession *) 0;
(void) OCIInitialize((ub4) OCI_DEFAULT, (dvoid *)0,
			(dvoid * (*)(dvoid *, size_t)) 0,
                      (dvoid * (*)(dvoid *, dvoid *, size_t))0,
                      (void (*)(dvoid *, dvoid *)) 0 );

(void) OCIEnvInit( (OCIEnv **) &envhp, OCI_DEFAULT, (size_t) 0, (dvoid **) 0 );

(void) OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &errhp, OCI_HTYPE_ERROR, 
			(size_t) 0, (dvoid **) 0);

	/* server contexts */
(void) OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &srvhp, OCI_HTYPE_SERVER,
			(size_t) 0, (dvoid **) 0);

(void) OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &svchp, OCI_HTYPE_SVCCTX,
			(size_t) 0, (dvoid **) 0);

(void) OCIServerAttach( srvhp, errhp, (text *) alias, strlen(alias), 0);
	/* set attribute server context in the service context */

(void) OCIAttrSet( (dvoid *) svchp, OCI_HTYPE_SVCCTX, (dvoid *)srvhp, (ub4) 0,
				OCI_ATTR_SERVER, (OCIError *) errhp);

(void) OCIHandleAlloc((dvoid *) envhp, (dvoid **)&authp, (ub4) OCI_HTYPE_SESSION,
				(size_t) 0, (dvoid **) 0);
 
(void) OCIAttrSet((dvoid *) authp, (ub4) OCI_HTYPE_SESSION,
			(dvoid *) username, (ub4) strlen((char *)username),
			(ub4) OCI_ATTR_USERNAME, errhp);
 
(void) OCIAttrSet((dvoid *) authp, (ub4) OCI_HTYPE_SESSION,
			(dvoid *) password, (ub4) strlen((char *)password),
			(ub4) OCI_ATTR_PASSWORD, errhp);

checkerr(errhp, OCISessionBegin ( svchp,  errhp, authp, OCI_CRED_RDBMS, 
				(ub4) OCI_DEFAULT));

(void) OCIAttrSet((dvoid *) svchp, (ub4) OCI_HTYPE_SVCCTX,
				(dvoid *) authp, (ub4) 0,
				(ub4) OCI_ATTR_SESSION, errhp);

checkerr(errhp, OCIHandleAlloc( (dvoid *) envhp, (dvoid **) &stmthp,
				OCI_HTYPE_STMT, (size_t) 0, (dvoid **) 0));

#ifdef DEBUG
	syslog(LOG_INFO,"Preparing fmsg statement");
#endif
	/* prepare the statement fmsg, passing the PL/SQL text
        block as the statement to be prepared */
checkerr(errhp, 
	OCIStmtPrepare(	stmthp, 
			errhp, 
			(text *) fmsg, 
			(ub4) strlen(fmsg), 
			OCI_NTV_SYNTAX, 
			OCI_DEFAULT
	)
);
#ifdef DEBUG
	syslog(LOG_INFO,"fmsg statement prepared");
#endif
return 1;
}

int checkerr(OCIError *errhp, sword status)
{
	text errbuf[512];
	sb4 errcode = 0;

	switch (status)
	{
	case OCI_SUCCESS:
		break;
	case OCI_SUCCESS_WITH_INFO:
		syslog(LOG_ERR,"Error - OCI_SUCCESS_WITH_INFO");
		return 0;
	case OCI_NEED_DATA:
		syslog(LOG_ERR,"Error - OCI_NEED_DATA");
		return 0;
	case OCI_NO_DATA:
		syslog(LOG_ERR,"Error - OCI_NODATA");
		return 0;
	case OCI_ERROR:
		(void) OCIErrorGet((dvoid *)errhp, (ub4) 1, (text *) NULL, &errcode,
				errbuf, (ub4) sizeof(errbuf), OCI_HTYPE_ERROR);
		syslog(LOG_ERR,"Error - %s",errbuf);
		return 0;
	case OCI_INVALID_HANDLE:
		syslog(LOG_ERR,"Error - OCI_INVALID_HANDLE");
		return 0;
	case OCI_STILL_EXECUTING:
		syslog(LOG_ERR,"Error - OCI_STILL_EXECUTETING");
		return 0;
	case OCI_CONTINUE:
		syslog(LOG_ERR,"Error - OCI_CONTINUE");
		return 0;
	default:
		break;
  }
	return 1;
}


void oci_cleanup()
{

if (stmthp)
	checkerr(errhp, OCIHandleFree((dvoid *) stmthp, OCI_HTYPE_STMT));

if (errhp)
	(void) OCIServerDetach( srvhp, errhp, OCI_DEFAULT );

if (srvhp)
	checkerr(errhp, OCIHandleFree((dvoid *) srvhp, OCI_HTYPE_SERVER));

if (svchp)
	(void) OCIHandleFree((dvoid *) svchp, OCI_HTYPE_SVCCTX);

if (errhp)
	(void) OCIHandleFree((dvoid *) errhp, OCI_HTYPE_ERROR);
return;
}




void send_msg(char *message){
struct tm *newtime;
time_t long_time;
char today[BUF_SIZE];

time( &long_time );
newtime = localtime( &long_time );

/*
sprintf(ocibuffer,"%s\r%4d%02d%02d%02d%02d%02d",message,
	newtime->tm_year+1900,
	newtime->tm_mon+1,
	newtime->tm_mday,
	newtime->tm_hour,
	newtime->tm_min,
	newtime->tm_sec
	);
*/
strcpy(ocibuffer,message);

#ifdef DEBUG
	syslog(LOG_INFO,"Sending :%s",ocibuffer);
#endif


checkerr(errhp , OCIStmtExecute(svchp,stmthp, errhp, (ub4) 1, (ub4) 0, 
	(OCISnapshot *) NULL, (OCISnapshot *) NULL, OCI_COMMIT_ON_SUCCESS));

sprintf(today,"%4d%02d%02d%02d%02d%02d",
	newtime->tm_year+1900,
	newtime->tm_mon+1,
	newtime->tm_mday,
	newtime->tm_hour,
	newtime->tm_min,
	newtime->tm_sec
	);

syslog(LOG_INFO,"Message sent: %s",message);

}

