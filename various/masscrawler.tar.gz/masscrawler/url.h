/* @(#)url.h	1.2 14 Nov 1994
 *
 *      This is the header file for URL-related functions for the WWW
 *      project being developed in CS-701, Fall 1994 semester.
 *
 *      Christopher Vickery
 *
 */


#ifndef __URL_H__
#define __URL_H__


/*  Define values for the protocol field  */

#define	P_UNKNOWN	0
#define P_HTTP		1
#define P_FILE		2
#define P_FTP		3
#define P_TELNET	4
#define P_GOPHER	5


/*  Structure returned by parseURL()  */

typedef struct {

  int		protocolType;

  union {

    struct unknown_s {

      char		*specifier;

      } unknown;

    struct http_s {

      char		*hostName;
      int		portNumber;
      char		*identifier;

      } http;
    
	struct gopher_s {

      char		*hostName;
      int		portNumber;
      char		*identifier;

      } gopher;

    struct file_s {

      char		*pathname;

      } file;

    } info;
  }  url_t;


/*  Prototype for the parsing function  */

url_t * parseURL(char *);

#endif

