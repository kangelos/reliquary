/*
*
*
*  WWW masscrawler, file in the list of domains, file out the results
*
*
*  This software is Copyright Angelos Karageorgiou 
* 
*  Original summer of 1995 , reworked in 2001
*  usage: masscrawler filein fileout
*  if fileout is omitted stdout is used
*
*  filein is a list of domain names one at each line
*
*/

static char *version ="@(#)client.c	3.12 WWW miniclient 95/01/19";

#define BUFFER 102400
#define TIMEOUT 11 /* seconds */
#include "www.h"
#include <unistd.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>




/* global variables */
char tname[400],lastip[400];	/* hostname */
char ip[400];		/* ip in ascii format */
char server[400],lastserver[400];	/* apache ? */
url_t *myurl;
FILE *FILEOUT,*FILEIN;
int tofile=0;

void show(char *filename);
void headers(int sockfd);


int failed;
static jmp_buf	env_alrm;


/* The signal handler just clears the flag and re-enables itself. */
void catch_alarm (int sig) {
	siglongjmp(env_alrm, 1);
}

int check_alrm(int sj,char *tname){
  if (sj == 1){
        if (tofile) {
                fprintf(FILEOUT,
                "%s: [ALARM] Server Irresponsive: Unresolved\n", tname);
        }else{
                printf("%s: [ALARM] Server Irresponsive: Unresolved\n",tname);
        }
  }
return sj;
}



main(argc,argv)
int argc;
char **argv;
{
char url[400],temp[100];
char command[300];
char request[400],line[400],buffer[BUFFER];/* startup client to server thing */
char resource[100];	/* part of request */
char *valid;
int sockfd,n,locfile;
int sj,i;
char filein[300],fileout[300];
long numservers,j;


if (argc>1){	/* command line URL ? */
	strcpy(filein,argv[1]);
} else{
	printf(" filein  ? \n");
	exit(0);
}

if (argc>2){	/* command line URL ? */
	strcpy(fileout,argv[2]);
	tofile=1;
}

if ( tofile ){
	FILEOUT=fopen(fileout,"w");
	if ( ! FILEOUT ) {
		perror(fileout);
		exit -1;
	}
}

if ( (FILEIN=fopen(filein,"r"))==NULL) {
	perror(filein);
	exit -1;
}
	

while ( fgets(buffer,BUFFER,FILEIN) != NULL ) {
       	n=strlen(buffer);
	if (buffer[n-1]=='\n'){
       		buffer[n-1]='\0';
       		n--;
	}
	if (buffer[n-1]=='\r'){
       		buffer[n-1]='\0';
       		n--;
	}
	strcpy(line,buffer);
	i++;
	memset(buffer,'\0',BUFFER);

  
  sprintf(url,"http://www.%s/",line);

  signal (SIGALRM, catch_alarm);
  alarm(0);
  sj=sigsetjmp(env_alrm,1);
  if (check_alrm(sj,tname)==1) { close(sockfd); continue;}
  alarm(TIMEOUT);


  sockfd=checkhost(url,j); /* do something */

if  (myurl->protocolType == P_HTTP){
	if ( sockfd > 0) {
		sprintf(request,"HEAD / HTTP/1.0\r\n");  
		writen(sockfd,request,strlen(request));

		sprintf(temp,"Accept: text/plain\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"Accept: text/html\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"Host: %s\r\n",tname);
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"User-Agent: Lexis Scorpion\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"\r\n\r\n"); 
		writen(sockfd,temp,strlen(temp));

		headers(sockfd);
		close(sockfd);

	alarm(0);

		if (tofile)
		  fprintf(FILEOUT,"%s: %s: %s\n",tname,server,ip);  
		else
		  printf("%s: %s: %s\n",tname,server,ip); 

		strcpy(lastip,ip);
		strcpy(lastserver,server);

		cleanup(myurl);

		close(sockfd);
	} else {
	/*	 	printf("Socket Failed\n");  */
	}
	if ( tofile) fflush(FILEOUT); else fflush(stdout);
}
}

fclose(FILEOUT);
fclose(FILEIN);
exit(0);
}



/* ---------------
	checkhost, takes as a parameter a URL
	If the protocol is HTTP  or GOPHER and if all goes well the 
	function returns a ready made socket FD that points to
	the URL requested.
	If the protocol is FILE then it tries to open the file 
	requested
 ---------------*/
int checkhost(char *url,long index){
char temp[500],*where,protocol[500];
int sockfd,i,sj;
struct sockaddr_in serv_addr;
struct hostent *target;
unsigned long addr;
int file,portnum;

if ( (myurl=parseURL(url))==NULL)
	return -1;

if ( (myurl->protocolType != P_HTTP)&&
     (myurl->protocolType != P_FILE)&&
     (myurl->protocolType != P_GOPHER) ){
	printf("I do not know how to handle this protocol\n");
	return -1;
}

if   (myurl->protocolType == P_HTTP){

  portnum=myurl->info.http.portNumber;

  strcpy(tname,myurl->info.http.hostName);	/* make local copies*/

  /* addr=inet_addr(tname);			/* maybe in dotted numerical format */
/*  if ((target=gethostbyaddr((char *)&addr,4,AF_INET))==NULL)   unecessary */


    if ((target=gethostbyname(tname))==NULL){
	if (tofile) 
		fprintf(FILEOUT,"%s: Server Irresponsive: Unresolved\n",tname); 
	else
	 	printf("%s: Server Irresponsive: Unresolved\n",tname); 
      return -1;
    }
  memcpy(&serv_addr.sin_addr,target->h_addr,target->h_length);

  strcpy(ip,inet_ntoa(serv_addr.sin_addr));	/* ascii format for the IP */
  if (strcmp(ip,lastip)==0) {  /* found it */
	if ( tofile)
        	fprintf(FILEOUT,"%s: %s : %s : *PREVIOUS* \n",tname,lastserver,ip);
	else 
        	printf("%s: %s : %s : *PREVIOUS* \n",tname,lastserver,ip);
  return -1;
  } 

  serv_addr.sin_family=AF_INET;
  serv_addr.sin_port= htons(portnum);
  
  if ((sockfd=socket(target->h_addrtype,SOCK_STREAM,0))<0){
    perror("Cannot Create Socket\n");
    return -1;
  }
 

  if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
    if (tofile)
		fprintf(FILEOUT,"%s: Server Irresponsive: Cannot Connect\n",
		tname); 
    else
		printf("%s: Server Irresponsive: Cannot Connect\n",tname); 

    return -1;
  }
  return sockfd; /* we made it this far */
}
return -1;     /* all the way down here? die die die */ 
}



void cleanup(url_t *myurl)
{
switch(myurl->protocolType){
	case(P_FILE):
			free(myurl->info.file.pathname);
			free(myurl);
			break;
	case(P_HTTP):
			free(myurl->info.http.hostName);
			free(myurl->info.http.identifier);
			free(myurl);
			break;
	case(P_GOPHER):
			free(myurl->info.gopher.hostName);
			free(myurl->info.gopher.identifier);
			free(myurl);
			break;
	default:
			free(myurl);
			break;
}
}


/*
* Function show
* parameter filename
*
* displays the contents of the url , dumped in the file "filename"
* on the screen using a somewhat human format
*
*/
void show( char * filename)
{
FILE *in;
char line[20000],temp[20000],dummy[3];
int lines,i,j,hitoggle,foundend;
int inside;

inside=0;

if((in=fopen(filename,"r"))==NULL){
	perror(filename);
	exit(1);	
}
foundend=1;
hitoggle=lines=0;

while (!feof(in)){
	memset(line,'\0',sizeof(line));
	memset(temp,'\0',sizeof(temp));
	fgets(line,sizeof(line)-1,in);
		/* now beautify line */
	i=j=0;
	if (!foundend){
		while( (line[i]!='>')&&(line[i]!='\0') )
			i++;
		i++;
	foundend=1;
	}
	while( (line[i]!='\0')&&(line[i]!='\n')){
		if (line[i]=='<'){
			while((line[i]!='\0')&&(line[i]!='>')){ /* braindead */
				if (line[i]=='>')
					foundend=1;
				i++;
			}
		i++;
		}
		if ((line[i]!='\0')&&(line[i]!='<')&&(line[i]!='\n'))
			temp[j++]=line[i++];
	}
	temp[j]='\0';	
	printf("%s",temp);
	printf("\r\n");
}
fclose(in);
/* printf("---EOF---"); */
}








/*
 *  Get the headers from the temp file
 *
 *
 */
void headers(int sockfd){
char buffer[BUFFER];
int n,x;

do{
	memset(buffer,'\0',sizeof(buffer)); /* just cleaning */
	n=readline(sockfd,buffer,BUFFER-1);
	if ( n > 0 ){
        	x=strlen(buffer);
        	buffer[x-2]='\0';		/* \r  Fucking dos */
/* printf("%s\n",buffer);*/
		if ( strncasecmp(buffer,"Server",6) == 0 ) {
			strcpy(server,buffer+8);
		}
	}
}while ( n>0);

}




