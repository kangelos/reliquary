/* *> @(#)www.h	1.17 www header file %d%
 WWW project header file
 Angelos Karageorgiou
*/



#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <fcntl.h>
#include <syslog.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "url.h"
#include "http.h"


#define DEF_RESOURCE "/" 
#define EOL	\n\r
#define PERMS 0644
#define HTTP_PORT "80"
#define GOPHER_PORT "70"
#define MAX 40000

int checkhost(char *url,long index);
int readline(int fd,char *ptr,int length);
int writen(int fd,char *ptr,int nbytes);
void log(char *string);
void cleanup(url_t *myurl);
int parseGet(line_info_t *);
