/*  @(#)http.h	1.4 20 Nov 1994
 *
 *
 *      This is the header file for processing http requests from  WWW
 *      browsers being developed as a project in CS-701, Fall 1994.
 *
 *      Christopher Vickery
 *
 *
 */

#ifndef __HTTP_H__
#define __HTTP_H__

#define HTTP_VERSION		"HTTP/1.0"

/*  Methods and Request Types  */

/*    The following constants identify colon-delimited string that
 *    marks the beginning of each line of a client request.  These
 *    values are returned by receiveRequest() and may be used as
 *    index values into a list of request names.
 */

/*  Methods  */

/*    For CS-701, Fall 1994, the only method supported is M_GET  */

#define M_ENDOFHEADER          -1

#define M_UNKNOWN		0
#define M_GET			1
#define M_HEAD			2
#define M_CHECKOUT		3
#define M_SHOWMETHOD		4
#define M_PUT			5
#define M_DELETE		6
#define M_POST			7
#define M_LINK			8
#define M_UNLINK		9
#define M_CHECKIN		10
#define M_TEXTSEARCH		11
#define M_SPACEJUMP		12
#define M_SEARCH		13

/*  Request Types  */

/*    For CS-701, Fall 1994, the client must generate a R_USER_AGENT
 *    line, but no others are needed.  The server simply logs all
 *    requests to its log file without regard to the request type.
 */

#define R_FROM			101
#define R_ACCEPT		102
#define R_ACCEPT_ENCODING	103
#define R_ACCEPT_LANGUAGE	104
#define R_USER_AGENT		105
#define R_REFERER		106
#define R_AUTHORIZATION		107
#define R_CHARGE_TO		108
#define R_UNKNOWN		109


/*  A Node in a linked list of lines  */

typedef struct line_info_s line_info_t;

struct line_info_s {

  int		typeCode;	/*  A method or request type code  */
  char		*info;		/*  The cdr of the request line    */
  line_info_t	*next;

  };



/*  Function Prototypes  */

line_info_t 	*receiveRequest(int);
void            freeRequest(line_info_t *);
char 		*parseGET(int *type,char *headerline);
#endif

