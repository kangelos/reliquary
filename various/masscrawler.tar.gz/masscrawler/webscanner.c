/*
*
* WWW miniclient Program
*   User types a URL and the miniclient fetches it locally into a 
*   temporary file  , and echoes the file name on the tty
*
*  This software is Copyright Angelos Karageorgiou 
* 
*	Written for Netaxis on the summer of 1995
*
*
*/

static char *version ="@(#)client.c	3.12 WWW miniclient 95/01/19";


#include "www.h"
#include <unistd.h>


/* global variables */
char tempname[100];
char tname[400];	/* hostname */
url_t *myurl;

void show(char *filename);
void gshow(char *filename);

main(argc,argv)
int argc;
char **argv;
{
char url[400],temp[100];
char command[300];
char request[400];	/* startup client to server thing */
char resource[100];	/* part of request */
char *valid;
int sockfd,n,locfile;


if (argc>1)	/* command line URL ? */
	strcpy(url,argv[1]);
else{
	printf(" what do you wan me to grab ? \n");
	exit(0);
}
if ( ! feof(stdin) ){	
	sockfd=checkhost(url); /* do something */
	if ( sockfd > 0) {
	if (myurl->protocolType==P_HTTP){
		strcpy(resource,myurl->info.http.identifier);
		 sprintf(request,"HEAD %s HTTP/1.0\r\n",resource); 
			/* send request out */
		/* printf("Request is '%s'",request); */
		writen(sockfd,request,strlen(request));

		sprintf(temp,"Accept: text/plain\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"Host: %s\r\n",tname);
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"Accept: text/html\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"User-Agent: Lexis Scorpion\r\n");
		writen(sockfd,temp,strlen(temp)); 

		sprintf(temp,"\r\n");
		writen(sockfd,temp,strlen(temp)); 
		writen(sockfd,temp,strlen(temp)); 

		strcpy(tempname,tmpnam(NULL));
		dump(sockfd,tempname);
		gshow(tempname);
	}
			/* common for all protocols */
	if (myurl->protocolType==P_GOPHER){
		strcpy(resource,myurl->info.gopher.identifier);
		 sprintf(request,"%s\r\n",resource); 
		writen(sockfd,request,strlen(request));

		strcpy(tempname,tmpnam(NULL));
		dump(sockfd,tempname);
		gshow(tempname);
	}
	unlink(tempname);
	cleanup(myurl);
	}
}
close(sockfd);
exit(0);
}



/* ---------------
	checkhost, takes as a parameter a URL
	If the protocol is HTTP  or GOPHER and if all goes well the 
	function returns a ready made socket FD that points to
	the URL requested.
	If the protocol is FILE then it tries to open the file 
	requested
 ---------------*/
int checkhost(char *url){
char temp[100],*where,protocol[100];
int sockfd,i;
struct sockaddr_in serv_addr;
struct hostent *target;
unsigned long addr;
int file,portnum;


if ( (myurl=parseURL(url))==NULL)
	return -1;

if ( (myurl->protocolType != P_HTTP)&&
     (myurl->protocolType != P_FILE)&&
     (myurl->protocolType != P_GOPHER) ){
	printf("I do not know how to handle this protocol\n");
	return -1;
}

if   (myurl->protocolType == P_HTTP){

  portnum=myurl->info.http.portNumber;

  strcpy(tname,myurl->info.http.hostName);	/* make local copies*/
  addr=inet_addr(tname);			/* maybe in dotted numerical format */
  if ((target=gethostbyaddr((char *)&addr,4,AF_INET))==NULL)
    if ((target=gethostbyname(tname))==NULL){
      printf("Hostname: '%s' not found\n",tname);
      return -1;
    }
  
  memcpy(&serv_addr.sin_addr,target->h_addr,target->h_length);
  
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_port= htons(portnum);
  
  if ((sockfd=socket(target->h_addrtype,SOCK_STREAM,0))<0){
    perror("Cannot Create Socket\n");
    return -1;
  }
  
  if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
    perror("Cannot connect to Server\n");
	return -1;
  }
  return sockfd; /* we made it this far */
}
if   (myurl->protocolType == P_GOPHER){

  portnum=myurl->info.gopher.portNumber;

  strcpy(tname,myurl->info.gopher.hostName); /* make local copies*/
  addr=inet_addr(tname); /* maybe in dotted numerical format */
  if ((target=gethostbyaddr((char *)&addr,4,AF_INET))==NULL)
    if ((target=gethostbyname(tname))==NULL){
      printf("Hostname: '%s' not found\n",tname);
      return -1;
    }
  
  memcpy(&serv_addr.sin_addr,target->h_addr,target->h_length);
  
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_port= htons(portnum);
  
  if ((sockfd=socket(target->h_addrtype,SOCK_STREAM,0))<0){
    perror("Cannot Create Socket\n");
    return -1;
  }
  
  if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
    perror("Cannot connect to Server\n");
	return -1;
  }
  return sockfd; /* we made it this far */
}

if  (myurl->protocolType == P_FILE){
  file=open(myurl->info.file.pathname,O_RDONLY);
  return file;
}
return -1;     /* all the way down here? die die die */ 
}


/**
*function dump
*   takes as a parameter a socketfd and a filename
*   creates the file (zaps old copies of it )
* and dumps anything read over the socket to the file
* untill there is no more to be read 
****/
void dump(int sockfd,char *filename)
{
int n,file;
char var[301];

if ((file=creat(filename,PERMS))==-1){
	perror("file creation");
	exit(1);
}
do{
	memset(var,'\0',sizeof(var)); /* just cleaning */
	n=readline(sockfd,var,300);
	if ( n > 0 ){
		/* printf("%s",var);*/
		write(file,var,strlen(var));
	}
}while ( n>0);
close(file);
close(sockfd); /* all done */
}




void cleanup(url_t *myurl)
{
switch(myurl->protocolType){
	case(P_FILE):
			free(myurl->info.file.pathname);
			free(myurl);
			break;
	case(P_HTTP):
			free(myurl->info.http.hostName);
			free(myurl->info.http.identifier);
			free(myurl);
			break;
	case(P_GOPHER):
			free(myurl->info.gopher.hostName);
			free(myurl->info.gopher.identifier);
			free(myurl);
			break;
	default:
			free(myurl);
			break;
}
}


/*
* Function show
* parameter filename
*
* displays the contents of the url , dumped in the file "filename"
* on the screen using a somewhat human format
*
*/
void show( char * filename)
{
FILE *in;
char line[2000],temp[2000],dummy[3];
int lines,i,j,hitoggle,foundend;
int inside;

inside=0;

if((in=fopen(filename,"r"))==NULL){
	perror(filename);
	exit(1);	
}
foundend=1;
hitoggle=lines=0;

while (!feof(in)){
	memset(line,'\0',sizeof(line));
	memset(temp,'\0',sizeof(temp));
	fgets(line,sizeof(line)-1,in);
		/* now beautify line */
	i=j=0;
	if (!foundend){
		while( (line[i]!='>')&&(line[i]!='\0') )
			i++;
		i++;
	foundend=1;
	}
	while( (line[i]!='\0')&&(line[i]!='\n')){
		if (line[i]=='<'){
			while((line[i]!='\0')&&(line[i]!='>')){ /* braindead */
				if (line[i]=='>')
					foundend=1;
				i++;
			}
		i++;
		}
		if ((line[i]!='\0')&&(line[i]!='<')&&(line[i]!='\n'))
			temp[j++]=line[i++];
	}
	temp[j]='\0';	
	printf("%s",temp);
	printf("\r\n");
}
fclose(in);
/* printf("---EOF---"); */
}




#define BUFFER 1024

void gshow(char *argv){
char buffer[BUFFER];
FILE *fp;
int n;

if ( (fp=fopen(argv,"r"))==NULL)
		perror("open");

while(fgets(buffer,BUFFER,fp) != NULL){
        n=strlen(buffer);
        buffer[n-1]='\0';
	printf("%s",buffer);
        printf("\r\n");
}
printf("---EOF---");
}

