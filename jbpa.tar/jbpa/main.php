<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 TRansitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html><head><title>Main</title>

	
		
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
		<meta name="robots" content="noindex,follow">
        <link href="ldap.css" rel="stylesheet" type="text/css">
</head><body bgcolor="#ffffff">
		<table width="907" height="182" border="0" align="center">
          <tr>
            <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
          </tr>
          <tr>
            <td height="23" colspan="5"><?php
session_start();
include "inc/config.php";
//include "getdomq.php";
$LDAP_Server    =$server;
//$LDAP_Server    = "127.0.0.1" ;
$Filter         = "(mail=*)";
$username = $_POST{'username'} ;
$password = $_POST{'password'} ;
$domain = $_POST{'domain'};
$binddn = 'uid='. $username . ',ou='. $domain . $bn;
$BaseDN         = "ou=" . $domain . $bn;
//$ds = ldap_connect($LDAP_Server);
//printf("Connecting . . . \n");
$_SESSION['username'] = $username;
$_SESSION['password']   = $password;
$_SESSION['domain']     = $domain;
$_SESSION['LDAP_Server'] = $LDAP_Server;
$_SESSION['binddn'] = $binddn;
$_SESSION['BaseDN'] = $BaseDN;

if ($_POST['username'] && $_POST['password'] && $_POST['domain']){

//printf ("%s <br> %s <br> %s<br\n",$binddn ,$BaseDN,$password );
$ConnectionID = ldap_connect($LDAP_Server) ;


if ($ConnectionID) {
    ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);
//  printf("Connected to %s\n",$LDAP_Server);
//  printf("Binding as anonymous \n");

  $BindRes = @ldap_bind($ConnectionID, $binddn, $password) ;
  if ($BindRes) {
    printf("Welcome <strong>$username@$domain </strong>\n");
    $Result = @ldap_search($ConnectionID, $BaseDN, $Filter);
    if (! $Result) {
      printf("LDAP Error (%d)\n Description: %s\n",
        ldap_errno($ConnectionID),
        ldap_error($ConnectionID));
    } else {
      $entries = ldap_get_entries($ConnectionID,$Result);
      for ($i=0 ; $i < $entries["count"] ; $i++) {
        // printf("DN: %s -> \n",$entries[$i]["dn"]);
//        printf("email: %s<br>\n",$entries[$i]["mail"][0]);
      }
    }
  } else {
    die("Username or password doesnt match. <a href=\"login.html\" class=\"stdbutton\" style=\"float:left;\" >Try again.</a> \n");
  }
  
}else {
  printf("Unable to connect to %s\n",$LDAP_Server);

}
ldap_unbind($ConnectionID);
include "getdomq.php";
}else{
  header('Location: login.html');
  }

 ?></td>
          </tr>
          <tr>
            <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0"></a></div></td>
            <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0"></a></div></td>
            <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0"></a></div></td>
            <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
            <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0"></a></div></td>
          </tr>
          <tr>
            <td height="23"><div align="center"><a href="search.php"></a><a href="search.php">Search</a></div></td>
            <td><div align="center"><a href="show_all.php"></a><a href="show_all.php">List all</a></div></td>
            <td><div align="center"><a href="add.php"></a><a href="add.php"></a><a href="add.php">Add</a><a href="delete.php"></a><a href="delete.php"></a></div></td>
            <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
            <td><div align="center"><a href="modify_man.php"></a><a href="modify_man.php"></a><a href="logout.php"></a><a href="logout.php">Logout</a></div></td>
          </tr>

          <tr>
            <td height="78" colspan="5"><p><?php include 'inc/main.html';?></p>            </td>
          </tr>
        </table>
        <p align="center"><a href="logout.php"></a><?php include 'inc/footer.html';?></p>
		</body></html>
