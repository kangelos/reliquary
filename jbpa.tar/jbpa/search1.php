<link href="ldap.css" rel="stylesheet" type="text/css" />
<title>Search</title>
<div align="center">
<tr>
      <td height="23" colspan="6"><?php include 'inc/header.html';?></td>
  </tr>
    <tr>
      <td height="23"><table width="922" border="0" align="center">
        <tr>
          <td><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td><div align="center"><a href="search.php">Search</a></div></td>
          <td><div align="center"><a href="show_all.php">List all </a></div></td>
          <td><div align="center"><a href="add.php">Add</a></div></td>
          <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
          <td><div align="center"><a href="logout.php">Logout</a></div></td>
        </tr>
      </table>
      </td>
  </tr>
    <p>&nbsp;</p>
        <p>
          <?php
session_start();
include "inc/config.php";
$LDAP_Server    =$server;

//$LDAP_Server    = "127.0.0.1" ;
//$Filter         = "(mail=postmaster@vivit.gr)";
$username = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$domain = $_SESSION['domain'];
$Filter         = "mail=".$_POST{'search'}."*".$domain;
$binddn = 'uid='. $username . ',ou='. $domain . $bn;
$BaseDN         = "ou=" . $domain . $bn;
//$ds = ldap_connect($LDAP_Server);


//printf("Connecting . . . \n");


//printf ("%s <br> %s <br> %s<br\n",$binddn ,$BaseDN,$password );
$ConnectionID = ldap_connect($LDAP_Server) ;


if ($ConnectionID) {
    ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);
//  printf("Connected to %s\n",$LDAP_Server);
//  printf("Binding as anonymous \n");
  $BindRes = @ldap_bind($ConnectionID, $binddn, $password) ;
  if ($BindRes) {
 //   printf("All mails: \n");
    $Result = @ldap_search($ConnectionID, $BaseDN, $Filter);
    if (! $Result) {
      printf("LDAP Error (%d)\n Description: %s\n",
        ldap_errno($ConnectionID),
        ldap_error($ConnectionID));
    } else {
	$sorted=ldap_sort ( $ConnectionID, $Result, "uid" );
      $entries = ldap_get_entries($ConnectionID,$Result);
?>
<table width="988" height="28" border="0" align="center">
<tr class="boxItem">
    <td width="113"><div align="center"><strong>Status:</strong></div></td>
    <td width="99"><strong>Email:</strong></td>
    <td width="173"><div align="left"><strong>Full name: </strong></div></td>
    <td width="164"><div align="left"><strong>Available quota:</strong></div></td>
    <td width="217" colspan=4 ><div align="center"><strong>Actions:</strong></div></td>
  </tr>
<?

$row=0;
      for ($i=0 ; $i < $entries["count"] ; $i++) {
        // printf("DN: %s -> \n",$entries[$i]["dn"]);
        //printf("email: %s<br>\n",$entries[$i]["mail"][0]);
		$entry1= $entries[$i]["mail"][0];
		$quota1=$entries[$i]["mailquota"][0];
		list($quota0) = explode("S".$quota1);
		$quota[$i]=$quota1;
		$quota1 = round($quota1 / 1048576 * 100) / 100 . " Mb"; 
		//print $quota;
		$nam= $entries[$i]["cn"][0];
		$surn= $entries[$i]["sn"][0];
		$stat1= $entries[$i]["accountstatus"][0];
		list($entry0, $dom) = explode("@".$domain, $entry1);
		//(!isset($var))
/*		
if ( ! isset( $entries[0]["mailQuotaSize"][0] ) ) {
	$domq=$defdomq;
} else {
	$domq=$entries[0]["mailQuotaSize"][0];
}
$_SESSION['domq']=$domq;
*/
		
if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries1="";//[$i]["mailalternateaddress"][0];
else
$entries1=$entries[$i]["mailalternateaddress"][0];
//}
if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries2="";//[$i]["mailalternateaddress"][0];
else
$entries2=$entries[$i]["mailalternateaddress"][1];		
		
if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries3="";//[$i]["mailalternateaddress"][0];
else
$entries3=$entries[$i]["mailalternateaddress"][2];	

if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries4="";//[$i]["mailalternateaddress"][0];
else
$entries4=$entries[$i]["mailalternateaddress"][3];	

if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries5="";//[$i]["mailalternateaddress"][0];
else
$entries5=$entries[$i]["mailalternateaddress"][4];	

if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries6="";//[$i]["mailalternateaddress"][0];
else
$entries6=$entries[$i]["mailalternateaddress"][5];	

if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries7="";//[$i]["mailalternateaddress"][0];
else
$entries7=$entries[$i]["mailalternateaddress"][6];	

if (!isset($entries[$i]["mailalternateaddress"]))//[0] == ""){
$entries8="";//[$i]["mailalternateaddress"][0];
else
$entries8=$entries[$i]["mailalternateaddress"][7];	
		list($userat1, $dom) = explode("@".$domain, $entries1);
		list($userat2, $dom) = explode("@".$domain, $entries2);
		list($userat3, $dom) = explode("@".$domain, $entries3);
		list($userat4, $dom) = explode("@".$domain, $entries4);
		list($userat5, $dom) = explode("@".$domain, $entries5);
		list($userat6, $dom) = explode("@".$domain, $entries6);
		list($userat7, $dom) = explode("@".$domain, $entries7);
		list($userat8, $dom) = explode("@".$domain, $entries8);
		
		$alt1= $userat1;
		$alt2= $userat2;					
		$alt3= $userat3;
		$alt4= $userat4;
		$alt5= $userat5;
		$alt6= $userat6;
		$alt7= $userat7;
		$alt8= $userat8;
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries90="";
else
$entries90=$entries[$i]["mailforwardingaddress"][0];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries91="";
else
$entries91=$entries[$i]["mailforwardingaddress"][1];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries92="";
else
$entries92=$entries[$i]["mailforwardingaddress"][2];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries93="";
else
$entries93=$entries[$i]["mailforwardingaddress"][3];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries94="";
else
$entries94=$entries[$i]["mailforwardingaddress"][4];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries95="";
else
$entries95=$entries[$i]["mailforwardingaddress"][5];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries96="";
else
$entries96=$entries[$i]["mailforwardingaddress"][6];
if (!isset($entries[$i]["mailforwardingaddress"]))
$entries97="";
else
$entries97=$entries[$i]["mailforwardingaddress"][7];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries98="";
else
$entries98=$entries[$i]["mailforwardingaddress"][8];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries99="";
else
$entries99=$entries[$i]["mailforwardingaddress"][9];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries100="";
else
$entries100=$entries[$i]["mailforwardingaddress"][10];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries111="";
else
$entries111=$entries[$i]["mailforwardingaddress"][11];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries112="";
else
$entries112=$entries[$i]["mailforwardingaddress"][12];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries113="";
else
$entries113=$entries[$i]["mailforwardingaddress"][13];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries114="";
else
$entries114=$entries[$i]["mailforwardingaddress"][14];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries115="";
else
$entries115=$entries[$i]["mailforwardingaddress"][15];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries116="";
else
$entries116=$entries[$i]["mailforwardingaddress"][16];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries117="";
else
$entries117=$entries[$i]["mailforwardingaddress"][17];


if (!isset($entries[$i]["mailforwardingaddress"]))
$entries118="";
else
$entries118=$entries[$i]["mailforwardingaddress"][18];

if (!isset($entries[$i]["mailforwardingaddress"]))
$entries119="";
else
$entries119=$entries[$i]["mailforwardingaddress"][19];
		
		
		
		
		
		
		$fw1= $entries90;
		$fw2= $entries91;					
		$fw3= $entries92;
		$fw4= $entries93;
		$fw5= $entries94;
		$fw6= $entries95;
		$fw7= $entries96;
		$fw8= $entries97;
		$fw9= $entries98;
		$fw10= $entries99;
		$fw11= $entries100;
		$fw12= $entries111;
		$fw13= $entries112;
		$fw14= $entries113;
		$fw15= $entries114;
		$fw16= $entries115;
		$fw17= $entries116;
		$fw18= $entries117;
		$fw19= $entries118;
		$fw20= $entries119;




		//print $stat1;
		$row++;
		
//		print "<pre>";
//		print_r($entries[$i]['mailalternateaddress']);
//		print "</pre>";
		$catchall=0;
		for ( $ma=0; $ma<=8 ; $ma++ ) {
			if ( isset($entries[$i]["mailalternateaddress"][$ma] ) ){
				$myc="catchall" . "@" . $domain;
				if ( $entries[$i]["mailalternateaddress"][$ma]  == $myc ) {
					$catchall=1;
			}
		}
		}
		

		
		if ( ( $row % 2 ) == 0  ){
			$mybg="white";
		}
		else {
			$mybg="dfdfdf";
		}
		if ( $catchall==1 ) { $mybg="pink"; }		
		print "<tr bgcolor=\"" . $mybg . "\">";
		
		print "<td align=right>";
//print "<pre>";
//print_r($entries[$i]);		
//print "</pre>";

//$al=$entries[$i]["mailforwardingaddress"][$i++];
//print $al;

if ($entries[$i]["accountstatus"][0]=="active"){;
		print ("<div align=\"center\"><img src=\"images/Green.png\"alt=\"Account active\"border=\"0\"></div></td><td><a href=\"details.php?user=$entry1&nam=$nam&stat1=$stat1&quota=$quota1\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >$entry1 </a></td> \n"); 
		

}else{

}
if ($entries[$i]["accountstatus"][0]=="deleted"){;
print ("<div align=\"center\"><img src=\"images/Red.png\" alt=\"Account deleted\" border=\"0\"></div></td><td><a href=\"details.php?user=$entry1&nam=$nam&stat1=$stat1&quota=$quota1\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" ><strike><em>$entry1</strike></em></a></td> \n"); 

}else{
}
if ($entries[$i]["accountstatus"][0]=="created"){;
		print ("<div align=\"center\"><img src=\"images/ms_wr_n.gif\"alt=\"New account\"border=\"0\"></div></td><td><a href=\"details.php?user=$entry1&nam=$nam&stat1=$stat1&quota=$quota1\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" > $entry1</a></td> \n"); 

}else{
}	

			
			print ("<td> $nam</a></td> \n"); 
		//<img src="images/Delete_01.png" width="27" height="28" /><a href="delete.php">Delete</a>
			//print ("<td><a href=\"details.php?user=$entry1&nam=$nam&surn=$surn\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/Delete_01.png\"border=\"0\"></td>");	
			
			print ("<td> $quota1");	
			
			print ("<td><a href=\"catchall.php?user=$entry1\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/Contact.png\"alt=\"Set as catchall\"border=\"0\">");	
			
			print ("<td><a href=\"catchall_del.php?user=$entry1\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/Del_catch.png\"alt=\"Remove catchall\"border=\"0\">");	
			
			print ("<td><a href=\"modify.php?user=$entry1&nam=$nam&surn=$surn\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/s_pencil1_g.gif\"alt=\"Modify\"border=\"0\">");	
			
print ("<td><a href=\"forward.php?user=$entry1&fw1=$fw1&fw2=$fw2&fw3=$fw3&fw4=$fw4&fw5=$fw5&fw6=$fw6&fw7=$fw7&fw8=$fw8&fw9=$fw9&fw10=$fw10&fw11=$fw11&fw12=$fw12&fw13=$fw13&fw14=$fw14&fw15=$fw15&fw16=$fw16&fw17=$fw17&fw18=$fw18&fw19=$fw19&fw20=$fw20\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/Forward.png\"alt=\"Forward\"border=\"0\">");

			print ("<td><a href=\"modify_man.php?user=$entry0&alt1=$alt1&alt2=$alt2&alt3=$alt3&alt4=$alt4&alt5=$alt5&alt6=$alt6&alt7=$alt7&alt8=$alt8\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/alias.png\"alt=\"Alias\"border=\"0\">");	

	    	print ("<td><a href=\"delete.php?user=$entry1&nam=$nam&surn=$surn\" method=\"post\" name=\"eee\" class=\"stdbutton\" style=\"float:left;\" >&nbsp; <img src=\"images/Delete_01.png\"alt=\"Delete account\"border=\"0\"></a></td>");
		print "</tr>";	

				//$_SESSION[$entry1] = $entryses;
				
				//$entryses = $_SESSION[$entries[$i]["mail"][0]];
     //<form action="add1.php" method="post" target="_top">
		//print "<pre>";
		//print_r($entries[$i]);//["cn"]);
	    //print "</pre>";

      }
	 print "</table>";
    }
  } else {
  header('Location: login.html');
    //printf("Could not bind to LDAP Server \n");
  }
}else {
  printf("Unable to connect to %s\n",$LDAP_Server);
  //}
}
ldap_unbind($ConnectionID);
  ?>
<tr>
<tr><td colspan="2"></td>
    <tr><td colspan="2"></tr>
</table>
  <table width="907" border="0">
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong><?php 
print count($entries)-1;?>
&nbsp;emails found. </strong><span class="font9pt"></span></td>
    </tr>
    <tr>
      <td><p align="left" class="style1"><strong>
        <?php 
	$allq=array_sum($quota);
	  $fquota = round($allq / 1053741824 * 100) / 100 . " Gb Allocated";
//print $fquota;
//session_start();
//$_SESSION['quotasess'] = $allq;
//$quotasess=$_SESSION['quotasess'] ;
//print $quotasess;
if ($allq > $domq){

//print "Over quota, please delete some users.";
}else{
//print ("Mail quota summary: $fquota");
//print "<span class=\"style1\">&nbsp;&nbsp;ok</span> \n";
}

?>
      </strong><strong>      </strong></p>        </td>
    </tr>
  </table>
</div>
<p align="center">
  <?php include 'inc/footer.html';?></p>
</body></html>
