<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Alias</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>
</head>

<body>
<form action="modify_man1.php" method="post" target="_top">
    <div align="center">
      <table width="907" height="157" border="0">
        <tr>
          <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
      </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
        <td><div align="center"><a href="show_all.php">List all </a></div></td>
        <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
        <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
        <td><div align="center"><a href="logout.php">Logout</a></a><a href="delete.php"></a></div></td>
        </tr>
        <tr>
          <td height="78" colspan="5"><p>&nbsp;</p></td>
      </tr>
        </table>
      <blockquote>
        <table width="652" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="63"><div align="left"><strong><font face="Verdana" size="2">email:</font></strong></div></td>
            <td width="46"></td>
            <td width="115"><input name="email" type="text" id="email" value="<?php print $_GET['user'];?>" size="30" readonly=true /></td>
            <td width="428"><div align="left"><strong>@<?php
session_start();
$domain = $_SESSION['domain']; 
print $domain
?>
            </strong></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias1" type="text" id="alias1" value="<?php print $_GET['alt1'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias2" type="text" id="alias2" value="<?php print $_GET['alt2'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias3" type="text" id="alias3" value="<?php print $_GET['alt3'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias4" type="text" id="alias4" value="<?php print $_GET['alt4'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias5" type="text" id="alias5" value="<?php print $_GET['alt5'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias6" type="text" id="alias6" value="<?php print $_GET['alt6'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>            
              </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias7" type="text" id="alias7" value="<?php print $_GET['alt7'];?>" size="30" /></td>
            <td><div align="left">@<?php

$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Alias:</font></div></td>
            <td></td>
            <td><input name="alias8" type="text" id="alias8" value="<?php print $_GET['alt8'];?>" size="30" /></td>
            <td><div align="left">@<?php
$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td colspan="4">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="4"><div align="left"></div></td>
          </tr>
          <tr>
            <td colspan="4">
              
              <div align="left">
                <input name="modify" type="submit" id="modify" style="color:white;background-color:#666699;border-bottom:thin solid #222244;border-right:thin solid #222244;border-top:thin solid #9999cc;border-left:thin solid #9999cc;font-size:11px;font-family:Verdana,Helvetica,sans-serif;" value="Modify aliases" />
              </div></td>
          </tr>
        </table>
      </blockquote>
    </div>
  <blockquote><p align="center">
      <?php include 'inc/footer.html';?>
    </p>
  </blockquote>
</form>
</body>
</html>
