<title>adding user</title>
   <link href="ldap.css" rel="stylesheet" type="text/css" />
   <div align="center">
     <table width="907" height="157" border="0">
       <tr>
         <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
       </tr>
       <tr>
         <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
         <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
         <td width="147"><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
         <td width="147"><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
         <td width="250"><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
       </tr>
       <tr>
         <td width="140" height="23"><div align="center"><a href="search.php">Search</a></div></td>
         <td width="203"><div align="center"><a href="show_all.php">List all </a></div></td>
         <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a><a href="alias.php"></a></div></td>
         <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
         <td><div align="center"><a href="logout.php">Logout</a></div></td>
       </tr>
       <tr>
         <td height="78" colspan="5"><?php
session_start();
mb_internal_encoding("UTF-8");
include "inc/config.php";
$LDAP_Server    =$server;
//$LDAP_Server    = "127.0.0.1" ;
$username = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$domain = $_SESSION['domain'];
$qqq = $_SESSION['quotasess'];
$domq = $_SESSION['domq'];
$binddn = 'uid='. $username . ',ou='. $domain . $bn;
$BaseDN         = "ou=" . $domain . $bn;
$name_add = $_POST{'name_add'};
$user_add = $_POST{'user_add'};
//$surn_add = $_POST{'surn_add'};
$pass_add = $_POST{'pass_add'};
$pass_add2 = $_POST{'pass_add2'};
$mailq = $_POST{'select'};
$string1 = $user_add;
$mystring1 = mb_substr($string1,0,2);
$string2 = $user_add;
$mystring2 = mb_substr($string2,2,2);
$ConnectionID = ldap_connect($LDAP_Server);  
$okie = "User Added";

//if ($_POST['user_add'] && $_POST['pass_add'] && $_POST['pass_add2']&& $_POST['name_add']&& $_POST['surn_add']){
if ($_POST['user_add'] && $_POST['pass_add'] && $_POST['pass_add2']&& $_POST['name_add']){
if ($pass_add == $pass_add2) {
if ($qqq > $domq){
die ("You cannot add more users. Over Quota.");
}



if ($ConnectionID) {
	ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);
    $r = ldap_bind($ConnectionID, $binddn, $password);

	$info["uid"][0] = $user_add;
    $info["cn"][0] = $name_add ;
    $info["sn"][0] = $name_add;
	$info["objectclass"][0] = $obj1;//"top";
    $info["objectclass"][1]= $obj2;//"person";
	$info["objectclass"][2]= $obj3;//"inetOrgPerson";
	$info["objectclass"][3]= $obj4;//"qmailUser";
	$info["objectclass"][4]= $obj5;//"PureFTPdUser";
	$info["mail"][0] = $user_add."@".$domain;
	$info["homeDirectory"][0] = "/home/domains/".$domain."/".$mystring1."/".$mystring2."/".$user_add;
	$info["mailMessageStore"][0] = "/home/domains/".$domain."/".$mystring1."/".$mystring2."/".$user_add."/Maildir/";
	$info["accountStatus"][0] = $accstat;//"created";
	if ( isset ($alias_add ) ) {
		$info["mailAlternateAddress"][0] = $alias_add."@".$domain;
	}
	$info["mailReplyText"][0] = $mailreptext;//"Not Set Yet";
	$info["VacationStatus"][0] = $vac;//"inactive";
	$info["userPassword"][0]=  $pass_add;
	$info["mailQuota"][0] = $mailq;//"262144000". "S";
	$info["FTPQuotaMBytes"][0] = $ftpq;//"50";

//print "<pre>"; print_r($info); print "</pre>";

    $r = ldap_add($ConnectionID,'uid='. $user_add . ',ou='. $domain .$bn,$info);
	print ("User created.");
	 //print ("User created. <a href=\"main.php\" class=\"stdbutton\" style=\"float:left;\" >Go to the main menu.</a> \n");
//print $okie;
 	// header('Location: login.html');
    // if  ($r=0) {
	// header('Location: login.html');
	// }
	 	//print (;
		
//		}else{ echo"User Already Exists";
//		}
	     ldap_unbind($ConnectionID);
} else {
    echo "Unable to connect to LDAP server";
}
}else{
die ("Password not match.");
}
 } else {
 //print  $qqq;

    die("Required fields are empty. <a href=\"add.php\" class=\"stdbutton\" style=\"float:left;\" >Try again.</a> \n");
  }


 ?>&nbsp;</td>
       </tr>
     </table>
   </div>
   <p align="center">
     <?php include 'inc/footer.html';?>
   </p>
   
