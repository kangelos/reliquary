<title>Details</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: 10pt}
.style2 {font-size: 10pt; font-weight: bold; }
-->
</style>
<div align="center">
  <table width="907" height="214" border="0">
    <tr>
      <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
      <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
      <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
      <td><div align="center"><a href="show_all.php">List all </a></div></td>
      <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
      <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
      <td><div align="center"><a href="logout.php"> Logout</a></div></td>
    </tr>
    <tr>
      <td height="23" colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td height="23" colspan="5"><strong>Email : 
        <?php
print $_GET['user']; ?>
      &nbsp;</strong></td>
    </tr>
    <tr>
      <td height="25" colspan="5"><strong>Name : 
        <?php
print $_GET['nam']; ?>
      </strong></td>
    </tr>
    <tr>
      <td height="28" colspan="5"><span class="style1"><strong>Acount status: </strong><strong>
      <?php
print $_GET['stat1']; ?>
      </strong></span><strong> </strong></td>
    </tr>
    <tr>
      <td height="28" colspan="5"><p class="style2">Mail Quota: <strong>
        <?php
print $_GET['quota']; ?>
      </strong></p>      </td>
    </tr>
  </table>
</div>
