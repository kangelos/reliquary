function check_pass()
{
	var r=document.f1;
 if ((r.user_pass1.value!=""&&r.user_pass.value!="")&&(r.uemail.value!=""&&r.date.value!=""&&r.month.value!=""&&r.year.value!=""))
	{
	if(r.user_pass.value==r.user_pass1.value)
		{
          if (r.uname.value!=r.user_pass.value)
			{
			frm_submit();
			}
		else
			{
			alert("Ur password &username are similar.plz change!!");
			r.user_pass.value="";
            r.user_pass1.value="";
            r.user_pass.focus();
			}
		}
		else
		{
		 alert ("Ur passwords do not match.plz check");
		 r.user_pass.value="";
		 r.user_pass1.value="";
		 r.user_pass.focus();
		}
	   }
	   else
	{
     alert("Plz fill all the fields");

	}
}
  function frm_submit()
  {
  if ((document.f1.addr_1.value!="")&&(document.f1.addr_2.value!=""))
  {
  var res=confirm("Do u want to make any changes");
   if (res=="0")
   {
    document.f1.submit();
   }
   else
   {
   document.f1.name.focus();
   }
  }
  else
  {
  alert("Please fill all the fields");
  }
  }
  function datech()
  {
  	var r=document.f1;
	alert(" Inside datech()");
  if((r.month.selectedIndex==0)||(r.month.selectedIndex==2)||(r.month.selectedIndex==4)||(r.month.selectedIndex==6)||(r.month.selectedIndex==7)||(r.month.selectedIndex==9)||(r.month.selectedIndex==11))
	  {
	  		for(var i=1;i<32;i++)
    	 {
			 r.date.options[i].value=i;
		}
	  }
    else if (r.month.selectedIndex==1)
	  {
		for( var i=29;i<31;i++)
			 {

        r.date.options[i]=null;
			 }
        for(var i=1;i<29;i++)
			 {
        r.date.options[i].value=i;
			 }
		  }
	else
		{
		      r.date.options[30]=null;
			 for(var i=1;i<30;i++)
			  {
				 r.date.options[i].value=i;
			  }
	  }
  }

function countp ()
{
	r=document.f1;
   r.chk.value++;

}
function passlen()
{
	alert("inside");
r=document.f1;
if ((r.user_pass.value.length>8)&&(r.user_pass1.value.length>8))
           {
           alert(" ");
           }
           else
           {
           alert("Passwords shuld be atleast 8 chars");
           history.go(1);
           }

}
function  ccnoval()
	{
	r=document.f1;
	 if(r.cardprovi.selectedIndex==0)
		{	
		if(r.ccno.value.substr(0,4)=="9584")
			{
			alert("Validated");
			r.agree.focus();
			}
			else
			{
				alert ("Invalid AMEX Card");
			}
		 }
	else if	 (r.cardprovi.selectedIndex==1)
		{	
		if(r.ccno.value.substr(0,4)=="5548")
			{
			alert("Validated");
			r.agree.focus();
			}
			else
			{
				alert ("Invalid Visa Card");
			}
		 }
	else if	 (r.cardprovi.selectedIndex==2)
		{	
		if(r.ccno.value.substr(0,4)=="5546")
			{
			alert("Validated");
			r.agree.focus();
			}
			else
			{
				alert ("Invalid MasterCard Card");
			}
		 }
 else if (r.cardprovi.selectedIndex==3)
		{	
		if(r.ccno.value.substr(0,4)=="9465")
			{
			alert("Validated");
			r.agree.focus();
			}
			else
			{
				alert ("Invalid CitiBank Card");
			}
		 }
else if (r.cardprovi.selectedIndex==4)
		{	
		if(r.ccno.value.substr(0,4)=="5460")
			{
			alert("Validated");
			r.agree.focus();
			}
			else
			{
				alert ("Invalid HSBC Card");
			}
		 }
		 else
		{
			 alert ("Error Occured!!");
		}
}
