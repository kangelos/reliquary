<? 
	$server = "127.0.0.1";
	$bn=",ou=domains,o=top";
	$obj1 = "top";
    $obj2 = "person";
	$obj3 = "inetOrgPerson";
	$obj4 = "qmailUser";
	$obj5 = "PureFTPdUser";
    $accstat = "created";
	$mailreptext = "Not Set Yet";
	$vac = "inactive";
	$defdomq = 5368709120;
	$ftpq = "50";

?>
