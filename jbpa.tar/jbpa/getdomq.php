<?php

$Filter         = "(ou=". $domain . ")";
$BaseDN         =  $bn;

$LDAP_Server    =$server;
$username = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$domain = $_SESSION['domain'];
$binddn = 'uid='. $username . ',ou='. $domain .$bn;



$ConnectionID = ldap_connect($LDAP_Server) ;
if (! $ConnectionID) {
        printf("LDAP Error (%d)\n Description: %s\n",
        ldap_errno($ConnectionID),
        ldap_error($ConnectionID));
	exit (1);
}

	ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);

  $BindRes = @ldap_bind($ConnectionID, $binddn, $password) ;
  if (! $BindRes) {
      printf("LDAP Error (%d)\n Description: %s\n",
        ldap_errno($ConnectionID),
        ldap_error($ConnectionID));
	exit (1);
}


    $Result = @ldap_search($ConnectionID, $BaseDN, $Filter);
    if (! $Result) {
      printf("LDAP Error (%d)\n Description: %s\n",
        ldap_errno($ConnectionID),
        ldap_error($ConnectionID));
	exit( 1);
    } 
$entries = ldap_get_entries($ConnectionID,$Result);

if ( ! isset( $entries[0]["mailquotasize"][0] ) ) {
	$domq=$defdomq;
} else {
	$domq=$entries[0]["mailquotasize"][0];
}
$_SESSION['domq']=$domq;
?>
