<?php


session_start();
	
	session_register("username");
	session_register("password");
	session_register("domain");
	session_unset();
	session_destroy();	
	header('Location: login.html');

?>

<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="refresh" content="2;URL=index.php">
</head>

<body>
<a href="login.html">Click here to return 
</a>
</body>
</html>
