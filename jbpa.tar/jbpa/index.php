<?php


//session_start();
	
	//session_register("username");
	//session_register("password");
	//session_register("domain");
	//session_unset();
	//session_destroy();	
	header('Location: login.html');

?>