<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Forward</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="forward1.php" method="post" target="_top">
    <div align="center">
      <table width="907" height="157" border="0">
        <tr>
          <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
      </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
        <td><div align="center"><a href="show_all.php">List all </a></div></td>
        <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
        <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
        <td><div align="center"><a href="logout.php">Logout</a></a><a href="delete.php"></a></div></td>
        </tr>
        <tr>
          <td height="78" colspan="5"><p>&nbsp;</p></td>
      </tr>
      </table>
      <blockquote>
        <table border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="44"><strong><font face="Verdana" size="2">email:</font></strong></td>
            <td width="15"></td>
            <td width="92"><input name="email" readonly=true type="text" id="email" value="<?php print $_GET['user'];?>" size="30" /></td>
            <td width="23">&nbsp;</td>
            <td width="12">&nbsp;</td>
            <td width="11">&nbsp;</td>
            <td width="47">&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias1" type="text" id="alias1" value="<?php print $_GET['fw1'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias11" type="text" id="alias11" value="<?php print $_GET['fw11'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias2" type="text" id="alias2" value="<?php print $_GET['fw2'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias12" type="text" id="alias12" value="<?php print $_GET['fw12'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias3" type="text" id="alias3" value="<?php print $_GET['fw3'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias13" type="text" id="alias13" value="<?php print $_GET['fw13'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias4" type="text" id="alias4" value="<?php print $_GET['fw4'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias14" type="text" id="alias14" value="<?php print $_GET['fw14'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias5" type="text" id="alias5" value="<?php print $_GET['fw5'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias15" type="text" id="alias15" value="<?php print $_GET['fw15'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias6" type="text" id="alias6" value="<?php print $_GET['fw6'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias16" type="text" id="alias16" value="<?php print $_GET['fw16'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias7" type="text" id="alias7" value="<?php print $_GET['fw7'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias17" type="text" id="alias17" value="<?php print $_GET['fw17'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias8" type="text" id="alias8" value="<?php print $_GET['fw8'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias18" type="text" id="alias18" value="<?php print $_GET['fw18'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias9" type="text" id="alias9" value="<?php print $_GET['fw9'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias19" type="text" id="alias19" value="<?php print $_GET['fw19'];?>" size="30" /></td>
          </tr>
          <tr>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td></td>
            <td><input name="alias10" type="text" id="alias10" value="<?php print $_GET['fw10'];?>" size="30" /></td>
            <td>&nbsp;</td>
            <td><font face="Verdana" size="2">Forward:</font></td>
            <td>&nbsp;</td>
            <td><input name="alias20" type="text" id="alias20" value="<?php print $_GET['fw20'];?>" size="30" /></td>
          </tr>
          <tr>
            <td colspan="7">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="7">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="7"><input name="modify" type="submit" id="modify" style="color:white;background-color:#666699;border-bottom:thin solid #222244;border-right:thin solid #222244;border-top:thin solid #9999cc;border-left:thin solid #9999cc;font-size:11px;font-family:Verdana,Helvetica,sans-serif;" value=" Modify" /></td>
          </tr>
        </table>
      </blockquote>
    </div>
  <blockquote><p align="center">
      <?php include 'inc/footer.html';?>
    </p>
  </blockquote>
</form>
</body>
</html>
