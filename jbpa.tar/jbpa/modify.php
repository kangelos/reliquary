<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Modify</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="modify1.php" method="post" target="_top">
    <div align="center">
      <table width="907" height="157" border="0">
        <tr>
          <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
      </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
        <td><div align="center"><a href="show_all.php">List all </a></div></td>
        <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
        <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
        <td><div align="center"><a href="logout.php">Logout</a></div></td>
        </tr>
        <tr>
          <td height="78" colspan="5"><p>&nbsp;</p>      </td>
      </tr>
        </table>
      <blockquote>
        <table border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="44"><div align="left"><font face="Verdana" size="2">Email:</font></div></td>
            <td width="15"></td>
            <td width="92"><input name="email" readonly=true type="text" id="email" value="<?php print $_GET['user'];?>" size="20" /></td>
            <td width="93">&nbsp;</td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Password:</font></div></td>
            <td></td>
            <td><input name="pass_mod" type="text" id="pass_mod" size="20" /></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Name:</font></div></td>
            <td></td>
            <td><input name="name_mod" type="text" id="name_mod" value="<?php print $_GET['nam'];?>"size="20" /></td>
            <td>&nbsp;</td>
          </tr>
<!--
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Surname:</font></div></td>
            <td></td>
            <td><input name="surn_mod" type="text" id="surn_mod" value="<?php print $_GET['surn'];?>"size="20" /></td>
            <td>&nbsp;</td>
          </tr>
-->
          <tr>
            <td colspan="4"><input name="modify" type="submit" id="modify" style="color:white;background-color:#666699;border-bottom:thin solid #222244;border-right:thin solid #222244;border-top:thin solid #9999cc;border-left:thin solid #9999cc;font-size:11px;font-family:Verdana,Helvetica,sans-serif;" value=" Modify" /></td>
          </tr>
        </table>
      </blockquote>
    </div>
  <blockquote><p align="center">
      <?php include 'inc/footer.html';?>
    </p>
  </blockquote>
</form>
</body>
</html>
