<title>adding user</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
<div align="center">
  <table width="907" height="157" border="0">
    <tr>
      <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
      <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
      <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
      <td><div align="center"><a href="show_all.php">List all </a></div></td>
      <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
      <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
      <td><div align="center"><a href="logout.php">Logout</a></div></td>
    </tr>
    <tr>
      <td height="78" colspan="5"><p><?php
session_start();
include "inc/config.php";
$LDAP_Server    =$server;
//$LDAP_Server    = "127.0.0.1" ;
$username = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$domain = $_SESSION['domain'];
$binddn = 'uid='. $username . ',ou='. $domain . $bn;
$BaseDN   = "ou=" . $domain . $bn;
$email_mod = $_POST{'email'}; 
$i=0;
$alias_mod[$i++] = $_POST{'alias1'};
$alias_mod[$i++] = $_POST{'alias2'};
$alias_mod[$i++] = $_POST{'alias3'};
$alias_mod[$i++] = $_POST{'alias4'};
$alias_mod[$i++] = $_POST{'alias5'};
$alias_mod[$i++] = $_POST{'alias6'};
$alias_mod[$i++] = $_POST{'alias7'};
$alias_mod[$i++] = $_POST{'alias8'};
list($user, $dom) = explode("@".$domain, $email_mod);
$ConnectionID = ldap_connect($LDAP_Server);  
$okie = "User Added";
//if ($_POST['pass_mod'] && $_POST['email'] && $_POST['name_mod']&& $_POST['surn_mod']){
if ($ConnectionID) {
	ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);
    $r = ldap_bind($ConnectionID, $binddn, $password);


$j=0;
for ( $i=0; $i<8; $i++) {
	if ( $alias_mod[$i] ) {
		$info["mailAlternateAddress"][$j++] = $alias_mod[$i] . "@" . $domain;
	}
}

//print "<pre>"; print_r($alias_mod); print "</pre>";

//print "INFO <pre>"; print_r($info); print "</pre>";

if ( $j == 0 ) {
	$attrs["mailAlternateAddress"]=array();
  $r = ldap_mod_del($ConnectionID,'uid='. $user . ',ou='. $domain .",ou=domains,o=vivodi",$attrs);
	 print ("Alias(es) Removed."); 
}else {
    $r = ldap_modify($ConnectionID,'uid='. $user . ',ou='. $domain .$bn,$info);
	 print ("Alias(es) Modified."); //<a href=\"main.php\" class=\"stdbutton\" style=\"float:left;\" >Go to the main menu.</a> \n");
	     ldap_unbind($ConnectionID);
} 

}else {
    //echo "Unable to connect to LDAP server";
	 
}
//} else {
 //header('Location: login.html');
  //  die("Required fields are empty. "); //<a href=\"modify.php\" class=\"stdbutton\" style=\"float:left;\" >Try again.</a> \n");
//  }


 ?></p></td>
    </tr>
  </table>
</div>
<p align="center">
  <?php include 'inc/footer.html';?>
</p>
