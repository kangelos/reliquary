<title>adding user</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
<div align="center">
  <table width="907" height="157" border="0">
    <tr>
      <td height="23" colspan="5"><?php include 'inc/header.html';?></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
      <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
      <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
      <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
    </tr>
    <tr>
      <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
      <td><div align="center"><a href="show_all.php">List all </a></div></td>
      <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
      <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
      <td><div align="center"><a href="logout.php">Logout</a></div></td>
    </tr>
    <tr>
      <td height="78" colspan="5"><p><?php
session_start();
include "inc/config.php";
$LDAP_Server    =$server;
//$LDAP_Server    = "127.0.0.1" ;
$username = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$domain = $_SESSION['domain'];
$binddn = 'uid='. $username . ',ou='. $domain . $bn;
$BaseDN   = "ou=" . $domain . $bn;
$email_mod = $_POST{'email'}; 
$i=0;
$alias_mod[$i++] = $_POST{'alias1'};
$alias_mod[$i++] = $_POST{'alias2'};
$alias_mod[$i++] = $_POST{'alias3'};
$alias_mod[$i++] = $_POST{'alias4'};
$alias_mod[$i++] = $_POST{'alias5'};
$alias_mod[$i++] = $_POST{'alias6'};
$alias_mod[$i++] = $_POST{'alias7'};
$alias_mod[$i++] = $_POST{'alias8'};
$alias_mod[$i++] = $_POST{'alias9'};
$alias_mod[$i++] = $_POST{'alias10'};
$alias_mod[$i++] = $_POST{'alias11'};
$alias_mod[$i++] = $_POST{'alias12'};
$alias_mod[$i++] = $_POST{'alias13'};
$alias_mod[$i++] = $_POST{'alias14'};
$alias_mod[$i++] = $_POST{'alias15'};
$alias_mod[$i++] = $_POST{'alias16'};
$alias_mod[$i++] = $_POST{'alias17'};
$alias_mod[$i++] = $_POST{'alias18'};
$alias_mod[$i++] = $_POST{'alias19'};
$alias_mod[$i++] = $_POST{'alias20'};

list($user, $dom) = explode("@".$domain, $email_mod);
$ConnectionID = ldap_connect($LDAP_Server);  
//if ($_POST['pass_mod'] && $_POST['email'] && $_POST['name_mod']&& $_POST['surn_mod']){
if ($ConnectionID) {
	ldap_set_option($ConnectionID, LDAP_OPT_PROTOCOL_VERSION, 3);
    $r = ldap_bind($ConnectionID, $binddn, $password);

$j=0;
for ( $i=0; $i<20; $i++) {
	if ( $alias_mod[$i] ) {
		$info["mailForwardingAddress"][$j++] = $alias_mod[$i];// . "@" . $domain;
		//$info["accountStatus"][0] = "active";
	}
}

//print "<pre>"; print_r($info); print "</pre>";
if ( $j == 0 ) {
	$attrs["mailForwardingAddress"]=array();
  $r = ldap_mod_del($ConnectionID,'uid='. $user . ',ou='. $domain .$bn,$attrs);
	 print ("Forward Removed."); 
}else {
    $r = ldap_modify($ConnectionID,'uid='. $user . ',ou='. $domain .$bn,$info);
	 print ("Forward Modified."); //<a href=\"main.php\" class=\"stdbutton\" style=\"float:left;\" >Go to the main menu.</a> \n");
	     ldap_unbind($ConnectionID);
} 

	     ldap_unbind($ConnectionID);
} else {
    //echo "Unable to connect to LDAP server";
	 
}

 ?></p></td>
    </tr>
  </table>
</div>
<p align="center">
  <?php include 'inc/footer.html';?>
</p>
