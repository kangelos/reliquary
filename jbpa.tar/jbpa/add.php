<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Add User</title>
<link href="ldap.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="add1.php" method="post" target="_top">
    <div align="center">
      <table width="907" height="157" border="0">
        <tr>
          <td height="23" colspan="5"><div align="left">
            <?php include 'inc/header.html';?>
          </div></td>
      </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td width="240"><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td width="131" height="23"><div align="center"><a href="search.php">Search</a></div></td>
        <td width="219"><div align="center"><a href="show_all.php">List all </a></div></td>
        <td width="153"><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
        <td width="142"><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
        <td><div align="center"><a href="logout.php"> Logout</a></div></td>
        </tr>
        <tr>
          <td height="78" colspan="5">&nbsp;</td>
      </tr>
        </table>
      <blockquote>
        <table border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td colspan="4"><strong>Add a new User ? </strong></td>
          </tr>
          <tr>
            <td colspan="4">&nbsp;</td>
          </tr>
          <tr>
            <td width="125"><div align="left"><font face="Verdana" size="2">Email:</font></div></td>
            <td width="9"><div align="left"><font color="#FF0000">*</font></div></td>
            <td width="102">
              
              <div align="left">
                <input name="user_add" type="text" id="user_add" size="20"/>
              </div></td>
            <td width="297"><div align="left">@<?php
session_start();
$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td height="20"><div align="left">Password<font color="#000000">:</font></div></td>
            <td height="20"><div align="left"><font color="#FF0000">*</font></div></td>
            <td height="20" colspan="2">
              
              <div align="left">
                <input name="pass_add" type="password" id="pass_add" size="20" />
              </div></td></tr>
          <tr>
            <td height="20"><div align="left">Retype Password<font color="#000000">:</font></div></td>
            <td height="20"><div align="left"><font color="#FF0000">*</font></div></td>
            <td height="20" colspan="2">
                
              <div align="left">
                <input name="pass_add2" type="password" id="pass_add2" size="20" />
              </div></td>
          </tr>
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Name :</font></div></td>
            <td><div align="left"><font color="#FF0000">*</font></div></td>
            <td colspan="2">              
              
              <div align="left">
                <input name="name_add" type="text" id="name_add" size="20" />
              </div></td>
          </tr>
<!--
          <tr>
            <td><div align="left"><font face="Verdana" size="2">Surname:</font></div></td>
            <td><div align="left"><font color="#FF0000">*</font></div></td>
            <td colspan="2">
              
              <div align="left">
                <input name="surn_add" type="text" id="surn_add" size="20" />
              </div></td>
          </tr>
-->
          <tr>
            <td height="20"><div align="left">Mail Quota : </div></td>
            <td height="20"><div align="left"></div></td>
            <td height="20"><label>
              
                <div align="left">
                    <select name="select" class="color_green">
                      <option value="52428800S"> 50 MB</option>
                      <option value="104857600S">100 MB</option>
                      <option value="262144000S">250 MB</option>
                      <option value="524288000S">500 MB</option>
                    </select>
              </div>
            </label></td>
            <td height="20"><div align="left"></div></td>
          </tr>
          <tr>
            <td colspan="4" height="20"><div align="right"><font color="#FF0000" size="2">*</font><font size="2"> Required fields</font><font size="1"> </font></div></td>
          </tr>
          <tr>
            <td><input name="submit" type="submit" style="color:white;background-color:#666699;border-bottom:thin solid #222244;border-right:thin solid #222244;border-top:thin solid #9999cc;border-left:thin solid #9999cc;font-size:11px;font-family:Verdana,Helvetica,sans-serif;" value=" Add user" /></td>
            <td>&nbsp;</td>
            <td colspan="2">&nbsp;</td>
          </tr>
        </table>
      </blockquote>
    </div>
  <blockquote><p align="center">
      <?php include 'inc/footer.html';?>
    </p>
  </blockquote>
</form>
</body>
</html>
