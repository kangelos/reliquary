<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search page</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function filter()
{
window.open('inc/filter.html','mywindow','width=656,height=194,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,copyhistory=no,resizable=no');
}

//-->
</script>



<link href="ldap.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="search1.php" method="post" target="_top">
    <div align="center">
      <table width="907" height="100" border="0">
        <tr>
          <td height="23" colspan="5"><div align="left">
            <?php include 'inc/header.html';?>
          </div></td>
      </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php"><img src="images/Preview Docment.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="show_all.php"><img src="images/Document.png" width="27" height="27" border="0" /></a></div></td>
          <td><div align="center"><a href="add.php"><img src="images/Add.png" width="27" height="28" border="0" /></a></div></td>
          <td><div align="center"><strong><a href="help.php" target="_blank" class="font14pt">?</a></strong></div></td>
          <td><div align="center"><a href="logout.php"><img src="images/Delete.png" width="27" height="28" border="0" /></a></div></td>
        </tr>
        <tr>
          <td height="23"><div align="center"><a href="search.php">Search</a></div></td>
        <td><div align="center"><a href="show_all.php">List all </a></div></td>
        <td><div align="center"><a href="add.php"></a><a href="add.php">Add</a></div></td>
        <td><div align="center"><a href="help.php" target="_blank">Help!</a></div></td>
        <td><div align="center"><a href="logout.php">Logout</a></div></td>
        </tr>
        <tr>
          <td height="21" colspan="5">&nbsp;</td>
      </tr>
        </table>
      <blockquote>
        <table width="334" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="24"><div align="center"><font face="Verdana" size="2"><a href="javascript:filter()"><strong>?</strong></a></font></div></td>
            <td width="61"><div align="center"><font face="Verdana" size="2"><a href="javascript:filter()">Filter :</a></font></div></td>
            <td width="11"></td>
            <td width="102"><input name="search" type="text" id="search" size="20" /></td>
            <td width="136"><div align="left">@<?php
session_start();
$domain = $_SESSION['domain']; 
print $domain
?>
            </div></td>
          </tr>
          <tr>
            <td colspan="5" height="20"></td>
          </tr>
          <tr>
            <td colspan="5"><input name="submit" type="submit" style="color:white;background-color:#666699;border-bottom:thin solid #222244;border-right:thin solid #222244;border-top:thin solid #9999cc;border-left:thin solid #9999cc;font-size:11px;font-family:Verdana,Helvetica,sans-serif;" value=" Search" /></td>
          </tr>
        </table>
      </blockquote>
    </div>
  <blockquote><p align="center">
      <?php include 'inc/footer.html';?>
    </p>
  </blockquote>
</form>
</body>
</html>
